# AI Video Translator — 100% Local & Offline Setup Guide

এই সফটওয়্যারটি সম্পূর্ণ **Offline ও Local AI Processing Engine** দিয়ে পরিচালিত। এতে কোনো **OpenAI**, **Google Cloud API**, **Paid Translation API**, বা **External Cloud Service** এর প্রয়োজন নেই। **কোনো API key লাগবে না।**

---

## ১. কীভাবে Backend চালু করতে হবে (How to Start Backend)

### লিনাক্স / ম্যাক (Linux / macOS):
```bash
# ১. backend ডিরেক্টরিতে যান
cd backend

# ২. স্ক্রিপ্টটি এক্সিকিউটেবল করুন এবং রান করুন
chmod +x run_backend.sh
./run_backend.sh
```

### উইন্ডোজ (Windows):
```cmd
cd backend
run_backend.bat
```

বা ম্যানুয়ালি টার্মিনালে:
```bash
cd backend
python -m venv venv

# অ্যাক্টিভেট করুন:
source venv/bin/activate     # Linux / macOS
# অথবা
venv\Scripts\activate        # Windows

# ডিপেন্ডেন্সি ইন্সটল করুন:
pip install -r requirements.txt

# সার্ভার স্টার্ট করুন:
python main.py
```
সার্ভারটি `http://localhost:8000` এ রিয়েল-টাইম কিউ ও হার্ডওয়্যার ডিটেকশন সহ চালু হবে।

---

## ২. কীভাবে Local AI Models ডাউনলোড করতে হবে (Download Local Models)

মডেলগুলো একবার ডাউনলোড হয়ে গেলে ইন্টারনেট সম্পূর্ণ বন্ধ করে দিলেও সিস্টেম স্বয়ংক্রিয়ভাবে লোকাল স্টোরেজ থেকে চলবে।

এক ক্লিকে সব ওপেন-সোর্স মডেল ডাউনলোড করার স্ক্রিপ্ট:
```bash
cd backend
python download_models.py
```

এই কমান্ডটি নিচের ওপেন-সোর্স মডেলগুলো লোকাল ড্রাইভে সেভ করে:
- **Speech-to-Text**: `Faster-Whisper` (medium/small)
- **Translation**: `Helsinki-NLP/opus-mt-bn-en`, `opus-mt-en-bcl`, ও `facebook/nllb-200-distilled-600M`
- **Speaker Diarization**: Local Acoustic Clustering & Pitch Estimator
- **Text-to-Speech**: `Piper TTS` / Local Neural Voice Synthesizer

---

## ৩. Models কোথায় রাখতে হবে (Model Storage Locations)

সব মডেল ফাইলের জন্য ডিরেক্টরি স্ট্রাকচার:
```text
backend/
├── models/
│   ├── stt/                 # Faster-Whisper weights (medium / small)
│   ├── translation/         # MarianMT / NLLB-200 weights
│   ├── diarization/         # PyAnnote / acoustic profile weights
│   └── tts/                 # Piper ONNX voice profiles (.onnx, .json)
├── storage/                 # স্থানীয়ভাবে রেন্ডার হওয়া MP4, WAV, SRT ফাইল
├── engine/                  # স্থানীয় AI পাইপলাইন ইঞ্জিন
├── main.py                  # ব্যাকএন্ড সার্ভার ও কিউ সিস্টেম
└── requirements.txt
```

---

## ৪. FFmpeg কীভাবে ইন্সটল করতে হবে (FFmpeg Installation)

ভিডিও থেকে অডিও নিষ্কাশন এবং ফাইনাল ভিডিওতে সাবটাইটেল ও অডিও যুক্ত করার জন্য লোকাল FFmpeg প্রয়োজন:

- **Ubuntu / Debian**:
  ```bash
  sudo apt update && sudo apt install -y ffmpeg
  ```
- **macOS (Homebrew)**:
  ```bash
  brew install ffmpeg
  ```
- **Windows**:
  - `winget install Gyan.FFmpeg` অথবা `choco install ffmpeg`
  - অথবা [gyan.dev/ffmpeg/builds](https://www.gyan.dev/ffmpeg/builds/) থেকে ডাউনলোড করে System `PATH` এ যুক্ত করুন।

যাচাই করতে টার্মিনালে লিখুন: `ffmpeg -version`

---

## ৫. GPU Support কীভাবে Enable করতে হবে (CUDA Acceleration)

আপনার কম্পিউটারে NVIDIA GPU থাকলে PyTorch CUDA সংস্করণ ইনস্টল করুন:
```bash
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu121
```
`main.py` চালু করার সময় কনসোলে স্বয়ংক্রিয়ভাবে দেখাবে:
`Device: NVIDIA GeForce RTX ... | CUDA Mode Active | Estimated Speed: 1.8x real-time`

---

## ৬. CPU Mode কীভাবে চালাতে হবে (CPU Fallback Mode)

GPU না থাকলে কোনো কনফিগারেশন পরিবর্তন করতে হবে না। সিস্টেম স্বয়ংক্রিয়ভাবে CPU Mode সনাক্ত করবে:
- ইনফারেন্স স্বয়ংক্রিয়ভাবে `int8` কোয়ান্টাইজেশনে রান করবে।
- ব্যবহারকারীকে আনুমানিক সময় (Estimated processing time) UI-তে প্রদর্শন করা হবে।

---

## ৭. কোনো API Key ছাড়াই কীভাবে সফটওয়্যার চালাতে হবে (Zero API Key Guarantee)

1. অ্যাপটি চালু করুন।
2. কোনো **API Key ইনপুট ফিল্ড বা প্রম্পট নেই**।
3. লোকাল ব্যাকএন্ড চালু থাকলে অ্যাপ সরাসরি `http://10.0.2.2:8000` (অ্যান্ড্রয়েড এমুলেটর) অথবা আপনার লোকাল আইপিতে কানেক্ট হবে।
4. যদি ব্যাকএন্ড কম্পিউটার বন্ধও থাকে, মোবাইল অ্যাপের **Built-in On-Device Offline Engine** সরাসরি ফোনে অডিও এক্সট্র্যাক্ট করে, অ্যাকোস্টিক পিচ বিশ্লেষণ করে স্পিকার আলাদা করবে, অফলাইন অনুবাদ করবে এবং সাবটাইটেল ও অডিও তৈরি করবে।
