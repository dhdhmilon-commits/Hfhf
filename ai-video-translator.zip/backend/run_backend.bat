@echo off
REM Startup script for Windows
echo ==========================================================
echo   Starting Local AI Video Translator Server (100%% Offline)
echo   No External APIs | No API Keys Needed
echo ==========================================================

cd /d "%~dp0"

python --version >nul 2>&1
if errorlevel 1 (
    echo Python 3 is required. Please install Python 3.10+ and add to PATH.
    pause
    exit /b 1
)

if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
)

call venv\Scripts\activate.bat
echo Installing/verifying local requirements...
pip install -r requirements.txt

echo Launching FastAPI local engine on http://localhost:8000...
python main.py
pause
