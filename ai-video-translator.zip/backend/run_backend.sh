#!/usr/bin/env bash
# Startup script for Local AI Video Translator Backend
set -e

echo "=========================================================="
echo "  Starting Local AI Video Translator Server (100% Offline)"
echo "  No External APIs | No API Keys Needed"
echo "=========================================================="

cd "$(dirname "$0")"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is required. Please install Python 3.10+."
    exit 1
fi

# Check virtual environment
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate
echo "Installing/verifying local requirements..."
pip install -r requirements.txt --quiet

# Launch Backend
echo "Launching FastAPI local engine on http://0.0.0.0:8000..."
python3 main.py
