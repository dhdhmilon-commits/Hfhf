"""
Local Offline Translation Engine.
Powered by open-source NLLB-200 (facebook/nllb-200-distilled-600M) and MarianMT.
100% Offline | Zero Cloud APIs | Zero API Keys Required.
"""

import os
import torch

class LocalTranslationEngine:
    def __init__(self, models_dir=None):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.models_dir = models_dir or os.path.join(os.path.dirname(__file__), "..", "models", "translation")
        
        # NLLB-200 / MarianMT models
        self.nllb_model = None
        self.nllb_tokenizer = None
        
        self.marian_bn_en_model = None
        self.marian_bn_en_tokenizer = None
        
        self.marian_en_bn_model = None
        self.marian_en_bn_tokenizer = None
        
        # Comprehensive FLORES-200 Language Mapping for NLLB-200 (200+ Languages Offline)
        self.nllb_lang_codes = {
            "bn": "ben_Beng",
            "en": "eng_Latn",
            "hi": "hin_Deva",
            "es": "spa_Latn",
            "fr": "fra_Latn",
            "de": "deu_Latn",
            "ar": "arb_Arab",
            "ur": "urd_Arab",
            "zh": "zho_Hans",
            "ja": "jpn_Jpan",
            "ru": "rus_Cyrl",
            "pt": "por_Latn",
            "it": "ita_Latn",
            "tr": "tur_Latn",
            "ko": "kor_Hang",
            "id": "ind_Latn",
            "vi": "vie_Latn",
            "ta": "tam_Taml",
            "te": "tel_Telu",
            "mr": "mar_Deva",
            "gu": "guj_Gujr",
            "pa": "pan_Guru",
            "fa": "pes_Arab",
            "nl": "nld_Latn",
            "pl": "pol_Latn",
            "sv": "swe_Latn",
            "th": "tha_Thai",
            "el": "ell_Grek",
            "cs": "ces_Latn",
            "ro": "ron_Latn",
            "hu": "hun_Latn",
            "uk": "ukr_Cyrl",
            "ms": "zsm_Latn"
        }

    def load_models(self):
        """Loads local neural machine translation models from offline disk cache."""
        if self.nllb_model is not None or self.marian_bn_en_model is not None:
            return

        print(f"[LocalTranslation] Initializing offline neural translation on {self.device}...")
        
        # 1. Try loading NLLB-200 (universal offline multi-language model)
        try:
            from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
            nllb_name = "facebook/nllb-200-distilled-600M"
            
            # Check local cache
            nllb_path = os.path.join(self.models_dir, "nllb-200-distilled-600M")
            load_target = nllb_path if os.path.exists(nllb_path) else nllb_name
            
            print(f"[LocalTranslation] Attempting to load NLLB-200 from {load_target}...")
            self.nllb_tokenizer = AutoTokenizer.from_pretrained(
                load_target,
                cache_dir=self.models_dir
            )
            dtype = torch.float16 if self.device == "cuda" else torch.float32
            self.nllb_model = AutoModelForSeq2SeqLM.from_pretrained(
                load_target,
                cache_dir=self.models_dir,
                torch_dtype=dtype
            ).to(self.device)
            print("[LocalTranslation] ✓ NLLB-200 offline translation model loaded successfully.")
            return
        except Exception as e:
            print(f"[LocalTranslation] NLLB-200 not available in cache: {e}")

        # 2. Try loading MarianMT for Bangla <-> English as alternative offline models
        try:
            from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
            
            # Bangla -> English
            bn_en_name = "Helsinki-NLP/opus-mt-bn-en"
            print(f"[LocalTranslation] Loading MarianMT {bn_en_name}...")
            self.marian_bn_en_tokenizer = AutoTokenizer.from_pretrained(bn_en_name, cache_dir=self.models_dir)
            self.marian_bn_en_model = AutoModelForSeq2SeqLM.from_pretrained(bn_en_name, cache_dir=self.models_dir).to(self.device)
            
            # English -> Multilingual (including Bangla)
            en_mul_name = "Helsinki-NLP/opus-mt-en-mul"
            print(f"[LocalTranslation] Loading MarianMT {en_mul_name}...")
            self.marian_en_bn_tokenizer = AutoTokenizer.from_pretrained(en_mul_name, cache_dir=self.models_dir)
            self.marian_en_bn_model = AutoModelForSeq2SeqLM.from_pretrained(en_mul_name, cache_dir=self.models_dir).to(self.device)
            print("[LocalTranslation] ✓ MarianMT offline models loaded successfully.")
            return
        except Exception as e:
            print(f"[LocalTranslation] MarianMT not available in cache: {e}")

        # If neither model could be loaded, warn the user clearly
        print("[LocalTranslation] ⚠️ No local translation weights found in models/translation.")

    def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        """
        Translates text strictly using local neural models.
        Zero external cloud APIs. No Google Translate, no DeepL, no API keys.
        """
        clean_text = text.strip()
        if not clean_text:
            return ""

        if self.nllb_model is None and self.marian_bn_en_model is None:
            self.load_models()

        # Route to NLLB-200 if loaded
        if self.nllb_model is not None and self.nllb_tokenizer is not None:
            return self._translate_nllb(clean_text, source_lang, target_lang)

        # Route to MarianMT if loaded
        if source_lang == "bn" and target_lang == "en" and self.marian_bn_en_model is not None:
            return self._translate_marian_bn_en(clean_text)

        if source_lang == "en" and target_lang == "bn" and self.marian_en_bn_model is not None:
            return self._translate_marian_en_bn(clean_text)

        # Honest failure if weights are missing — NEVER return fake dictionary mocks
        err_msg = (
            "স্থানীয় অফলাইন অনুবাদ মডেল (NLLB-200 / MarianMT) লোড করা যায়নি। "
            "অনুগ্রহ করে 'python download_models.py' চালিয়ে মডেল ডাউনলোড করুন। "
            "কোনো ক্লাউড বা পেইড এপিআই ব্যবহার করা হবে না।"
        )
        raise RuntimeError(err_msg)

    def _translate_nllb(self, text: str, source_lang: str, target_lang: str) -> str:
        # Determine source FLORES-200 code
        if "_" in source_lang:
            src_code = source_lang
        else:
            src_code = self.nllb_lang_codes.get(source_lang, "eng_Latn" if source_lang == "en" else "ben_Beng")

        # Determine target FLORES-200 code
        if "_" in target_lang:
            tgt_code = target_lang
        else:
            tgt_code = self.nllb_lang_codes.get(target_lang, "ben_Beng" if target_lang == "bn" else "eng_Latn")

        self.nllb_tokenizer.src_lang = src_code
        inputs = self.nllb_tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=256).to(self.device)
        
        forced_bos_token_id = getattr(self.nllb_tokenizer, "lang_code_to_id", {}).get(tgt_code)
        if forced_bos_token_id is None and hasattr(self.nllb_tokenizer, "convert_tokens_to_ids"):
            forced_bos_token_id = self.nllb_tokenizer.convert_tokens_to_ids(tgt_code)

        with torch.no_grad():
            gen_kwargs = {"max_length": 256, "num_beams": 4}
            if forced_bos_token_id is not None:
                gen_kwargs["forced_bos_token_id"] = forced_bos_token_id
            generated_tokens = self.nllb_model.generate(
                **inputs,
                **gen_kwargs
            )
        result = self.nllb_tokenizer.batch_decode(generated_tokens, skip_special_tokens=True)[0]
        return result.strip()

    def _translate_marian_bn_en(self, text: str) -> str:
        inputs = self.marian_bn_en_tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=256).to(self.device)
        with torch.no_grad():
            generated_tokens = self.marian_bn_en_model.generate(**inputs, max_length=256, num_beams=4)
        result = self.marian_bn_en_tokenizer.batch_decode(generated_tokens, skip_special_tokens=True)[0]
        return result.strip()

    def _translate_marian_en_bn(self, text: str) -> str:
        # For multilingual MarianMT, prepend target language tag >>ben<<
        prompt = f">>ben<< {text}"
        inputs = self.marian_en_bn_tokenizer(prompt, return_tensors="pt", padding=True, truncation=True, max_length=256).to(self.device)
        with torch.no_grad():
            generated_tokens = self.marian_en_bn_model.generate(**inputs, max_length=256, num_beams=4)
        result = self.marian_en_bn_tokenizer.batch_decode(generated_tokens, skip_special_tokens=True)[0]
        return result.strip()
