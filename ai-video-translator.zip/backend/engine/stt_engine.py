"""
Local Speech-to-Text Engine using Faster-Whisper.
Runs completely offline on local GPU or CPU.
100% Offline | Zero Cloud APIs | Zero API Keys Required.
"""

import os
import torch

class LocalSTTEngine:
    def __init__(self, model_size="medium", models_dir=None):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.compute_type = "float16" if self.device == "cuda" else "int8"
        self.model = None
        self.model_size = model_size
        self.models_dir = models_dir or os.path.join(os.path.dirname(__file__), "..", "models", "stt")

    def load_model(self):
        """Loads the local Faster-Whisper model into memory."""
        if self.model is not None:
            return

        print(f"[LocalSTT] Loading Faster-Whisper ({self.model_size}) on {self.device} ({self.compute_type})...")
        try:
            from faster_whisper import WhisperModel
            # Check if downloaded offline weights exist in models_dir
            model_path_or_size = self.model_size
            if os.path.exists(self.models_dir) and os.listdir(self.models_dir):
                model_path_or_size = self.models_dir

            self.model = WhisperModel(
                model_path_or_size,
                device=self.device,
                compute_type=self.compute_type,
                download_root=self.models_dir
            )
            print("[LocalSTT] Faster-Whisper successfully loaded into memory.")
        except Exception as e:
            err_msg = (
                f"Faster-Whisper model failed to load ({e}). "
                "Please ensure faster-whisper is installed and run 'python download_models.py' "
                "to download offline model weights. No external APIs will be used."
            )
            print(f"[LocalSTT] Error: {err_msg}")
            self.model = None
            raise RuntimeError(err_msg)

    def transcribe(self, audio_path: str, language: str = None) -> list:
        """
        Transcribes the audio file and yields segments with timestamps.
        language: 'bn' for Bangla, 'en' for English, or None for Auto-detect.
        Returns empty list if no speech detected.
        """
        if not os.path.exists(audio_path):
            raise FileNotFoundError(f"Audio file not found: {audio_path}")

        if self.model is None:
            self.load_model()

        segments_data = []
        lang_code = None if language in [None, "auto"] else language

        try:
            segments, info = self.model.transcribe(
                audio_path,
                language=lang_code,
                beam_size=5,
                vad_filter=True,
                vad_parameters=dict(min_silence_duration_ms=500)
            )

            for seg in segments:
                text_clean = seg.text.strip()
                if text_clean:
                    segments_data.append({
                        "start_ms": int(seg.start * 1000),
                        "end_ms": int(seg.end * 1000),
                        "text": text_clean,
                        "confidence": round(seg.avg_logprob, 3)
                    })

            print(f"[LocalSTT] Transcribed {len(segments_data)} speech segments (Language: {info.language}, Probability: {info.language_probability:.2f})")
            return segments_data
        except Exception as e:
            print(f"[LocalSTT] Transcription error: {e}")
            raise RuntimeError(f"Speech-to-Text transcription failed: {e}")
