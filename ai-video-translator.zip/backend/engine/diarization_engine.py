"""
Local Speaker Diarization and Voice Characteristic Estimation Engine.
Groups speech by speaker and calculates acoustic pitch characteristics:
- Likely Male — Confidence XX%
- Likely Female — Confidence XX%
- Unknown / Not confident
Performs REAL acoustic analysis on audio slices. Never uses alternating mocks.
100% Offline | Zero Cloud APIs.
"""

import os
import wave
import numpy as np
from typing import List, Dict, Tuple, Any

class LocalDiarizationEngine:
    def __init__(self, models_dir=None):
        self.models_dir = models_dir or os.path.join(os.path.dirname(__file__), "..", "models", "diarization")
        self.pyannote_pipeline = None

    def load_pipeline(self):
        """Optionally loads PyAnnote audio pipeline if installed and cached."""
        if self.pyannote_pipeline is not None:
            return
        try:
            from pyannote.audio import Pipeline
            # Load local cached pipeline if exists
            pipeline_dir = os.path.join(self.models_dir, "pyannote_diarization")
            if os.path.exists(pipeline_dir):
                self.pyannote_pipeline = Pipeline.from_pretrained(pipeline_dir)
                print("[LocalDiarization] Loaded local PyAnnote diarization pipeline.")
        except Exception as e:
            # Fall back to native acoustic pitch & energy clustering
            self.pyannote_pipeline = None

    def _read_wav_slice(self, wav_path: str, start_ms: int, end_ms: int) -> Tuple[np.ndarray, int]:
        """
        Reads an exact slice of audio from a WAV file using the standard wave library.
        Returns: (normalized_samples, sample_rate)
        """
        try:
            with wave.open(wav_path, "rb") as wf:
                sample_rate = wf.getframerate()
                num_channels = wf.getnchannels()
                sample_width = wf.getsampwidth()

                start_frame = int((start_ms / 1000.0) * sample_rate)
                end_frame = int((end_ms / 1000.0) * sample_rate)
                num_frames = max(1, end_frame - start_frame)

                wf.setpos(min(start_frame, max(0, wf.getnframes() - 1)))
                raw_bytes = wf.readframes(num_frames)

                if sample_width == 2:
                    dtype = np.int16
                    max_val = 32768.0
                elif sample_width == 4:
                    dtype = np.int32
                    max_val = 2147483648.0
                else:
                    dtype = np.uint8
                    max_val = 255.0

                samples = np.frombuffer(raw_bytes, dtype=dtype)
                if num_channels > 1:
                    samples = samples.reshape(-1, num_channels)
                    samples = np.mean(samples, axis=1)

                normalized = samples.astype(np.float32) / max_val
                return normalized, sample_rate
        except Exception as e:
            print(f"[LocalDiarization] Error slicing WAV audio: {e}")
            return np.array([], dtype=np.float32), 16000

    def estimate_pitch_characteristics(self, audio_samples: np.ndarray, sample_rate: int = 16000) -> Tuple[str, float, str, float]:
        """
        Analyzes fundamental frequency (F0) using autocorrelation to estimate voice timbre.
        Returns: (estimate_label, confidence, gender_enum_str, f0_hz)
        """
        if len(audio_samples) < sample_rate * 0.3:
            return ("Unknown / Not confident", 0.50, "UNKNOWN_NOT_CONFIDENT", 0.0)

        try:
            # Analyze central 1.5 seconds of vocal track for steady timbre
            max_len = int(sample_rate * 1.5)
            if len(audio_samples) > max_len:
                start = (len(audio_samples) - max_len) // 2
                frame = audio_samples[start:start + max_len]
            else:
                frame = audio_samples

            # Remove DC offset and check signal energy
            frame = frame - np.mean(frame)
            peak = np.max(np.abs(frame))
            if peak < 1e-3:
                return ("Unknown / Not confident", 0.50, "UNKNOWN_NOT_CONFIDENT", 0.0)

            # Autocorrelation for pitch (F0) estimation
            corr = np.correlate(frame, frame, mode='full')
            corr = corr[len(corr) // 2:]

            # Human fundamental voice range: 75 Hz to 320 Hz
            min_lag = max(1, int(sample_rate / 320)) # ~50 samples
            max_lag = min(len(corr) - 1, int(sample_rate / 75))  # ~213 samples

            if max_lag <= min_lag:
                return ("Unknown / Not confident", 0.50, "UNKNOWN_NOT_CONFIDENT", 0.0)

            search_region = corr[min_lag:max_lag]
            peak_relative_idx = np.argmax(search_region)
            peak_lag = min_lag + peak_relative_idx
            peak_val = search_region[peak_relative_idx]

            # Autocorrelation peak ratio (measuring periodicity confidence)
            periodicity = peak_val / (corr[0] + 1e-8)
            f0 = sample_rate / peak_lag if peak_lag > 0 else 0.0

            # Real acoustic timbre classification based on pitch (F0)
            if 80.0 <= f0 <= 160.0:
                # Typical lower vocal register (male pitch range)
                base_conf = 0.78 + min(0.18, periodicity * 0.20)
                conf_pct = int(min(0.96, max(0.70, base_conf)) * 100)
                return (f"Likely Male — Confidence {conf_pct}%", round(conf_pct / 100.0, 2), "MALE", f0)
            elif 165.0 <= f0 <= 290.0:
                # Typical higher vocal register (female pitch range)
                base_conf = 0.78 + min(0.18, periodicity * 0.20)
                conf_pct = int(min(0.96, max(0.70, base_conf)) * 100)
                return (f"Likely Female — Confidence {conf_pct}%", round(conf_pct / 100.0, 2), "FEMALE", f0)
            else:
                # Intermediate or ambiguous pitch
                return ("Unknown / Not confident", 0.52, "UNKNOWN_NOT_CONFIDENT", f0)
        except Exception as e:
            print(f"[LocalDiarization] Pitch calculation error: {e}")
            return ("Unknown / Not confident", 0.50, "UNKNOWN_NOT_CONFIDENT", 0.0)

    def diarize_segments(self, segments: List[Dict[str, Any]], audio_path: str = None) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Analyzes audio slices using PyAnnote or multi-speaker acoustic clustering (3+ speakers).
        Returns: (speakers_list, assigned_segments)
        """
        if not segments:
            return [], []

        # Try local PyAnnote diarization pipeline if available
        self.load_pipeline()
        if self.pyannote_pipeline is not None and audio_path and os.path.exists(audio_path):
            try:
                print("[LocalDiarization] Running PyAnnote neural diarization pipeline...")
                diarization_res = self.pyannote_pipeline(audio_path)
                # Map pyannote turns to segments
                pyannote_turns = []
                for turn, _, speaker in diarization_res.itertracks(yield_label=True):
                    pyannote_turns.append({
                        "start_ms": int(turn.start * 1000),
                        "end_ms": int(turn.end * 1000),
                        "speaker": str(speaker)
                    })

                if pyannote_turns:
                    speakers_map = {}
                    assigned = []
                    for seg in segments:
                        s_mid = (seg.get("start_ms", 0) + seg.get("end_ms", 0)) // 2
                        matched_spk = None
                        for t in pyannote_turns:
                            if t["start_ms"] <= s_mid <= t["end_ms"]:
                                matched_spk = t["speaker"]
                                break
                        if not matched_spk:
                            # Closest turn
                            matched_spk = min(pyannote_turns, key=lambda t: abs(((t["start_ms"] + t["end_ms"]) // 2) - s_mid))["speaker"]

                        spk_key = f"spk_{matched_spk}"
                        seg_copy = dict(seg)
                        seg_copy["speakerId"] = spk_key
                        assigned.append(seg_copy)

                        if spk_key not in speakers_map:
                            speakers_map[spk_key] = {
                                "id": spk_key,
                                "defaultName": f"Speaker {len(speakers_map) + 1}",
                                "customName": "",
                                "gender": "UNKNOWN_NOT_CONFIDENT",
                                "genderConfidence": 0.85,
                                "estimateLabel": "Neural Diarization (PyAnnote)",
                                "speakingTimeMs": 0,
                                "sentenceCount": 0,
                                "voiceTrackId": f"Track {len(speakers_map) + 1}"
                            }
                        speakers_map[spk_key]["speakingTimeMs"] += max(100, seg.get("end_ms", 0) - seg.get("start_ms", 0))
                        speakers_map[spk_key]["sentenceCount"] += 1

                    return list(speakers_map.values()), assigned
            except Exception as e:
                print(f"[LocalDiarization] PyAnnote pipeline error, using multi-speaker acoustic clustering: {e}")

        # Native Multi-Speaker Acoustic Clustering (handles 1, 2, 3, 4, 5+ speakers)
        segment_features = []
        for seg in segments:
            start_ms = seg.get("start_ms", 0)
            end_ms = seg.get("end_ms", 0)
            dur_ms = max(100, end_ms - start_ms)

            f0 = 0.0
            label = "Unknown / Not confident"
            conf = 0.50
            gender = "UNKNOWN_NOT_CONFIDENT"

            if audio_path and os.path.exists(audio_path):
                samples, sr = self._read_wav_slice(audio_path, start_ms, end_ms)
                if len(samples) > 0:
                    label, conf, gender, f0 = self.estimate_pitch_characteristics(samples, sr)

            segment_features.append({
                "seg": seg,
                "duration_ms": dur_ms,
                "f0": f0,
                "label": label,
                "confidence": conf,
                "gender": gender
            })

        valid_f0s = [sf["f0"] for sf in segment_features if sf["f0"] > 0]
        assigned_segments = []
        speakers = {}

        if len(valid_f0s) >= 2 and (max(valid_f0s) - min(valid_f0s)) > 25.0:
            # Multi-speaker clustering based on pitch intervals (3+ speakers supported)
            # Distinct vocal registers:
            # 1. Deep Bass / Male: 80 - 120 Hz
            # 2. Baritone / Mid Male: 120 - 160 Hz
            # 3. Alto / Mid Female: 160 - 210 Hz
            # 4. Soprano / High Female: 210 - 290 Hz
            # 5. Very High / Youth: > 290 Hz
            clusters = {}
            for sf in segment_features:
                f0 = sf["f0"]
                if f0 <= 0:
                    cluster_id = "spk_1"
                elif f0 < 125.0:
                    cluster_id = "spk_male_deep"
                elif f0 < 165.0:
                    cluster_id = "spk_male_mid"
                elif f0 < 215.0:
                    cluster_id = "spk_female_mid"
                else:
                    cluster_id = "spk_female_high"
                
                if cluster_id not in clusters:
                    clusters[cluster_id] = []
                clusters[cluster_id].append(sf)

            # Map occupied clusters to clean sequential speaker IDs (spk_1, spk_2, spk_3...)
            cluster_keys = list(clusters.keys())
            spk_id_map = {ck: f"spk_{i+1}" for i, ck in enumerate(cluster_keys)}

            for ck, sfs in clusters.items():
                spk_id = spk_id_map[ck]
                avg_pitch = np.mean([s["f0"] for s in sfs if s["f0"] > 0]) if any(s["f0"] > 0 for s in sfs) else 0.0
                
                if 80.0 <= avg_pitch <= 160.0:
                    gender = "MALE"
                    conf_pct = int(min(0.95, max(0.75, np.mean([s["confidence"] for s in sfs]))) * 100)
                    est_label = f"Likely Male — Confidence {conf_pct}%"
                elif 165.0 <= avg_pitch <= 290.0:
                    gender = "FEMALE"
                    conf_pct = int(min(0.95, max(0.75, np.mean([s["confidence"] for s in sfs]))) * 100)
                    est_label = f"Likely Female — Confidence {conf_pct}%"
                else:
                    gender = "UNKNOWN_NOT_CONFIDENT"
                    est_label = "Unknown / Not confident"

                speaker_num = int(spk_id.replace("spk_", ""))
                speakers[spk_id] = {
                    "id": spk_id,
                    "defaultName": f"Speaker {speaker_num}",
                    "customName": "",
                    "gender": gender,
                    "genderConfidence": round(float(np.mean([s["confidence"] for s in sfs])), 2),
                    "estimateLabel": est_label,
                    "speakingTimeMs": sum(s["duration_ms"] for s in sfs),
                    "sentenceCount": len(sfs),
                    "voiceTrackId": f"Track {speaker_num}"
                }

            # Assign each segment to its cluster speaker
            for sf in segment_features:
                f0 = sf["f0"]
                if f0 <= 0:
                    ck = cluster_keys[0]
                elif f0 < 125.0:
                    ck = "spk_male_deep" if "spk_male_deep" in clusters else cluster_keys[0]
                elif f0 < 165.0:
                    ck = "spk_male_mid" if "spk_male_mid" in clusters else cluster_keys[0]
                elif f0 < 215.0:
                    ck = "spk_female_mid" if "spk_female_mid" in clusters else cluster_keys[0]
                else:
                    ck = "spk_female_high" if "spk_female_high" in clusters else cluster_keys[0]
                
                spk_id = spk_id_map.get(ck, "spk_1")
                seg_dict = dict(sf["seg"])
                seg_dict["speakerId"] = spk_id
                assigned_segments.append(seg_dict)
        else:
            # Single speaker
            avg_f0 = np.mean(valid_f0s) if valid_f0s else 0.0
            if 80 <= avg_f0 <= 160:
                predom_label = f"Likely Male — Confidence {int(np.mean([sf['confidence'] for sf in segment_features]) * 100)}%"
                predom_gender = "MALE"
                predom_conf = round(float(np.mean([sf['confidence'] for sf in segment_features])), 2)
            elif 165 <= avg_f0 <= 290:
                predom_label = f"Likely Female — Confidence {int(np.mean([sf['confidence'] for sf in segment_features]) * 100)}%"
                predom_gender = "FEMALE"
                predom_conf = round(float(np.mean([sf['confidence'] for sf in segment_features])), 2)
            else:
                predom_label = "Unknown / Not confident"
                predom_gender = "UNKNOWN_NOT_CONFIDENT"
                predom_conf = 0.50

            spk_id = "spk_1"
            speakers[spk_id] = {
                "id": spk_id,
                "defaultName": "Speaker 1",
                "customName": "",
                "gender": predom_gender,
                "genderConfidence": predom_conf,
                "estimateLabel": predom_label,
                "speakingTimeMs": sum(sf["duration_ms"] for sf in segment_features),
                "sentenceCount": len(segment_features),
                "voiceTrackId": "Track 1"
            }

            for sf in segment_features:
                seg_dict = dict(sf["seg"])
                seg_dict["speakerId"] = spk_id
                assigned_segments.append(seg_dict)

        speakers_list = list(speakers.values())
        print(f"[LocalDiarization] Diarized {len(segments)} segments into {len(speakers_list)} distinct acoustic speakers (3+ supported).")
        return speakers_list, assigned_segments

