"""
Local Video and Audio Processing Engine using FFmpeg.
Handles audio extraction, audio synchronization, and final video rendering.
"""

import os
import subprocess
import json

class LocalVideoEngine:
    def __init__(self):
        self.ffmpeg_cmd = "ffmpeg"
        self.ffprobe_cmd = "ffprobe"

    def check_ffmpeg(self) -> bool:
        try:
            res = subprocess.run([self.ffmpeg_cmd, "-version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return res.returncode == 0
        except Exception:
            return False

    def probe_video(self, video_path: str) -> dict:
        """Inspects resolution, duration, audio channels, and bitrate."""
        try:
            cmd = [
                self.ffprobe_cmd,
                "-v", "quiet",
                "-print_format", "json",
                "-show_format",
                "-show_streams",
                video_path
            ]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if res.returncode == 0:
                data = json.loads(res.stdout)
                duration = float(data.get("format", {}).get("duration", 0))
                video_stream = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), {})
                width = int(video_stream.get("width", 1280))
                height = int(video_stream.get("height", 720))
                fps = eval(video_stream.get("r_frame_rate", "30/1"))
                return {
                    "duration_sec": duration,
                    "width": width,
                    "height": height,
                    "fps": round(fps, 2),
                    "format": data.get("format", {}).get("format_name", "mp4")
                }
        except Exception as e:
            print(f"[FFprobe] Error probing video: {e}")
        return {"duration_sec": 30.0, "width": 1280, "height": 720, "fps": 30.0, "format": "mp4"}

    def extract_audio_wav(self, video_path: str, output_wav_path: str) -> bool:
        """Extracts 16kHz mono WAV audio required for local STT and Diarization."""
        try:
            cmd = [
                self.ffmpeg_cmd,
                "-y",
                "-i", video_path,
                "-vn",
                "-acodec", "pcm_s16le",
                "-ar", "16000",
                "-ac", "1",
                output_wav_path
            ]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return res.returncode == 0 and os.path.exists(output_wav_path)
        except Exception as e:
            print(f"[FFmpeg] Audio extraction error: {e}")
            return False

    def render_final_video(
        self,
        input_video_path: str,
        translated_audio_path: str,
        subtitles_srt_path: str,
        output_video_path: str,
        burn_subtitles: bool = True
    ) -> bool:
        """
        Renders final video:
        Replaces audio track with translated TTS audio and burns subtitles into video.
        Ensures the full video duration is never truncated (no -shortest bug).
        """
        try:
            # Probe original video duration to ensure exact duration match
            meta = self.probe_video(input_video_path)
            duration_sec = meta.get("duration_sec", 0.0)

            duration_args = []
            if duration_sec > 0:
                duration_args = ["-t", str(round(duration_sec, 3))]

            if burn_subtitles and os.path.exists(subtitles_srt_path):
                # Escaping for Windows & Unix paths in vf subtitles filter
                escaped_srt = subtitles_srt_path.replace("\\", "/").replace(":", "\\:")
                vf_arg = f"subtitles='{escaped_srt}':force_style='FontSize=20,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BackColour=&H80000000,Bold=1'"
                cmd = [
                    self.ffmpeg_cmd,
                    "-y",
                    "-i", input_video_path,
                    "-i", translated_audio_path,
                    "-c:v", "libx264",
                    "-preset", "fast",
                    "-crf", "22",
                    "-vf", vf_arg,
                    "-c:a", "aac",
                    "-b:a", "192k",
                    "-map", "0:v:0",
                    "-map", "1:a:0"
                ] + duration_args + [output_video_path]
            else:
                cmd = [
                    self.ffmpeg_cmd,
                    "-y",
                    "-i", input_video_path,
                    "-i", translated_audio_path,
                    "-c:v", "copy",
                    "-c:a", "aac",
                    "-b:a", "192k",
                    "-map", "0:v:0",
                    "-map", "1:a:0"
                ] + duration_args + [output_video_path]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return res.returncode == 0 and os.path.exists(output_video_path)
        except Exception as e:
            print(f"[FFmpeg] Video rendering error: {e}")
            return False
