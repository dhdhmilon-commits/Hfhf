package com.example.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.model.DialogueSegment
import com.example.model.Speaker
import com.example.model.VoiceType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _activeSegmentId = MutableStateFlow<String?>(null)
    val activeSegmentId: StateFlow<String?> = _activeSegmentId.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            tts?.language = Locale.US
        } else {
            Log.e("VoiceManager", "TextToSpeech init failed")
        }
    }

    fun speakPreview(speaker: Speaker, sampleText: String, targetLangCode: String = "en") {
        if (!isTtsReady || tts == null) return

        val locale = if (targetLangCode == "bn") Locale.forLanguageTag("bn-BD") else Locale.US
        val langResult = tts?.setLanguage(locale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }

        // Apply speaker specific voice pitch and speed characteristics
        val pitchMultiplier = when (speaker.selectedVoice) {
            VoiceType.FEMALE_VOICE -> 1.35f
            VoiceType.MALE_VOICE -> 0.85f
            VoiceType.NEUTRAL_VOICE -> 1.05f
        } * speaker.pitch

        val rateMultiplier = speaker.speed

        tts?.setPitch(pitchMultiplier)
        tts?.setSpeechRate(rateMultiplier)

        _isPlaying.value = true
        tts?.speak(sampleText, TextToSpeech.QUEUE_FLUSH, null, "speaker_${speaker.id}_preview")
    }

    fun speakSegment(segment: DialogueSegment, speaker: Speaker?) {
        if (!isTtsReady || tts == null) return

        val textToSpeak = segment.translatedText.ifBlank { segment.originalText }
        val langCode = segment.targetLanguage
        val locale = if (langCode == "bn") Locale.forLanguageTag("bn-BD") else Locale.US

        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }

        val pitch = (speaker?.let { spk ->
            when (spk.selectedVoice) {
                VoiceType.FEMALE_VOICE -> 1.35f
                VoiceType.MALE_VOICE -> 0.85f
                VoiceType.NEUTRAL_VOICE -> 1.05f
            } * spk.pitch
        } ?: 1.0f)

        val rate = speaker?.speed ?: 1.0f

        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)

        _activeSegmentId.value = segment.id
        _isPlaying.value = true
        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, segment.id)
    }

    fun stop() {
        tts?.stop()
        _isPlaying.value = false
        _activeSegmentId.value = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
