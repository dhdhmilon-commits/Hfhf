package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DialogueSegment
import com.example.model.Speaker
import com.example.model.SubtitleLanguageOption
import com.example.model.VideoItem
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimary
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerView(
    videoItem: VideoItem?,
    previewTab: Int, // 0: Original, 1: Translated
    onTabChange: (Int) -> Unit,
    dialogues: List<DialogueSegment>,
    speakers: List<Speaker>,
    showOriginalSubtitle: Boolean,
    showTranslatedSubtitle: Boolean,
    showSpeakerName: Boolean,
    showTimestamp: Boolean,
    subtitleLanguageOption: SubtitleLanguageOption,
    onSpeakDialogue: (DialogueSegment, Speaker?) -> Unit,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(false) }
    var currentPlaybackMs by remember { mutableLongStateOf(0L) }
    val totalDurationMs = videoItem?.durationMs ?: 20000L

    val speakerMap = remember(speakers) { speakers.associateBy { it.id } }

    // Synchronize dialogue subtitle playback with current time
    val currentSegment = remember(currentPlaybackMs, dialogues) {
        dialogues.firstOrNull { currentPlaybackMs >= it.startMs && currentPlaybackMs <= it.endMs }
    }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isPlaying && currentPlaybackMs < totalDurationMs) {
                delay(100)
                currentPlaybackMs += 100
            }
            if (currentPlaybackMs >= totalDurationMs) {
                isPlaying = false
                currentPlaybackMs = 0L
            }
        }
    }

    // Automatically speak when a dialogue starts in translated video preview mode
    var lastSpokenSegmentId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(currentSegment, isPlaying, previewTab) {
        if (isPlaying && previewTab == 1 && currentSegment != null && currentSegment.id != lastSpokenSegmentId) {
            lastSpokenSegmentId = currentSegment.id
            val spk = speakerMap[currentSegment.speakerId]
            onSpeakDialogue(currentSegment, spk)
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("video_player_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Tabs: Original Video | Translated Video
            TabRow(
                selectedTabIndex = previewTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
            ) {
                Tab(
                    selected = previewTab == 0,
                    onClick = { onTabChange(0) },
                    text = {
                        Text(
                            text = "Original Video",
                            fontWeight = if (previewTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = previewTab == 1,
                    onClick = { onTabChange(1) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Translated Video",
                                fontWeight = if (previewTab == 1) FontWeight.Bold else FontWeight.Normal
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = CircleShape,
                                color = EmeraldSuccess,
                                modifier = Modifier.size(6.dp)
                            ) {}
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Simulated Cinematic Video Canvas with Subtitle Overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF0F172A),
                                Color(0xFF020617)
                            )
                        )
                    )
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Background visual vibe
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (previewTab == 1) Icons.Default.Audiotrack else Icons.Default.Subtitles,
                        contentDescription = null,
                        tint = if (previewTab == 1) CyanAccent.copy(alpha = 0.4f) else IndigoPrimary.copy(alpha = 0.4f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (previewTab == 1) "Translated Video Player (Voice + Subtitles)" else "Original Video Playback",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = Color.White.copy(alpha = 0.5f)
                    )
                }

                // Top Badge: Active Mode & Audio Track
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.7f)
                    ) {
                        Text(
                            text = if (previewTab == 1) "TRANSLATED AUDIO ACTIVE" else "ORIGINAL AUDIO",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (previewTab == 1) CyanAccent else Color.White
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.7f)
                    ) {
                        Text(
                            text = "${DialogueSegment.formatMsToTimestamp(currentPlaybackMs)} / ${DialogueSegment.formatMsToTimestamp(totalDurationMs)}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = Color.White),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Dynamic Subtitle Overlay Box (Bottom Center)
                if (currentSegment != null) {
                    val spk = speakerMap[currentSegment.speakerId]
                    val speakerPrefix = if (showSpeakerName) "${spk?.displayName ?: "Speaker"}: " else ""

                    val displayText = when (subtitleLanguageOption) {
                        SubtitleLanguageOption.ORIGINAL_LANGUAGE -> currentSegment.originalText
                        SubtitleLanguageOption.TARGET_LANGUAGE -> currentSegment.translatedText
                        SubtitleLanguageOption.BOTH -> {
                            if (previewTab == 1) "${currentSegment.translatedText}\n[${currentSegment.originalText}]"
                            else "${currentSegment.originalText}\n[${currentSegment.translatedText}]"
                        }
                    }

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp, start = 16.dp, end = 16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.85f))
                            .border(1.dp, CyanAccent.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (showTimestamp) {
                            Text(
                                text = "${currentSegment.formattedStartTime()} • ${spk?.displayName ?: "Speaker"} (${spk?.gender?.labelEnglish ?: "Unknown"})",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                        }

                        Text(
                            text = "$speakerPrefix$displayText",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Player Controls: Play/Pause, Timeline scrubber, Replay
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { isPlaying = !isPlaying },
                    modifier = Modifier.testTag("play_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = CyanAccent,
                        modifier = Modifier.size(28.dp)
                    )
                }

                IconButton(
                    onClick = {
                        currentPlaybackMs = 0L
                        isPlaying = true
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay,
                        contentDescription = "Restart",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Slider(
                    value = currentPlaybackMs.toFloat(),
                    onValueChange = { currentPlaybackMs = it.toLong() },
                    valueRange = 0f..totalDurationMs.toFloat(),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
