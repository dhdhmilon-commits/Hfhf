package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DubbingVoiceMode
import com.example.model.SupportedLanguage
import com.example.model.VoiceProfile
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimary

@Composable
fun DubbingVoiceCard(
    selectedMode: DubbingVoiceMode,
    selectedVoiceId: String?,
    savedVoices: List<VoiceProfile>,
    targetLanguage: SupportedLanguage = SupportedLanguage.ENGLISH,
    useVoicePool: Boolean = false,
    voicePoolCount: Int = 0,
    onToggleVoicePool: (Boolean) -> Unit = {},
    onSelectDefaultVoice: () -> Unit,
    onSelectCustomVoice: (String) -> Unit,
    onOpenVoiceLibrary: () -> Unit,
    onSwitchToEnglish: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var expandedDropdown by remember { mutableStateOf(false) }

    val activeVoiceName = when {
        useVoicePool -> "মাল্টি-স্পিকার ভয়েস পুল (স্বয়ংক্রিয় অ্যাসাইনমেন্ট)"
        selectedMode == DubbingVoiceMode.CLONED && selectedVoiceId != null -> {
            savedVoices.find { it.id == selectedVoiceId }?.name ?: "কাস্টম ক্লোনড ভয়েস (XTTS-v2)"
        }
        else -> "ডিফল্ট ভয়েস (Piper / espeak-ng)"
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dubbing_voice_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(IndigoPrimary.copy(alpha = 0.35f))
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(IndigoPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Dubbing Voice",
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ডাবিং ভয়েস (Dubbing Voice)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "স্বয়ংক্রিয় ভয়েস পুল বা কাস্টম ক্লোনিং",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Voice Library Button
                OutlinedButton(
                    onClick = onOpenVoiceLibrary,
                    modifier = Modifier.testTag("open_voice_library_button"),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Voice",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Voice Pool (${voicePoolCount})",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Automatic Multi-Speaker Voice Pool Toggle Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .testTag("use_voice_pool_container"),
                color = if (useVoicePool) IndigoPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                border = BorderStroke(
                    1.dp,
                    if (useVoicePool) CyanAccent.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (useVoicePool) EmeraldSuccess.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = if (useVoicePool) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Use Voice Pool (অটো স্পিকার অ্যাসাইনমেন্ট)",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = if (voicePoolCount > 0)
                                    "ভিডিওতে যতজন স্পিকার থাকবে, পুলের $voicePoolCount টি ভয়েস থেকে স্বয়ংক্রিয়ভাবে ক্রমানুসারে বরাদ্দ হবে।"
                                else
                                    "Firebase Storage পুল থেকে বহু-স্পিকারের জন্য স্বয়ংক্রিয় ভয়েস বরাদ্দ।",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Switch(
                        checked = useVoicePool,
                        onCheckedChange = { onToggleVoicePool(it) },
                        modifier = Modifier.testTag("use_voice_pool_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = EmeraldSuccess,
                            checkedTrackColor = EmeraldSuccess.copy(alpha = 0.4f)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Selector Dropdown Box (Active when Voice Pool is disabled)
            if (!useVoicePool) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .clickable { expandedDropdown = true }
                            .testTag("dubbing_voice_dropdown"),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = if (selectedMode == DubbingVoiceMode.CLONED) EmeraldSuccess else IndigoPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = activeVoiceName,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (selectedMode == DubbingVoiceMode.CLONED) "কাস্টম নিউরাল ক্লোনড ভয়েস (XTTS-v2)" else "ডিফল্ট লোকাল ভয়েস সিন্থেসিস (Piper/espeak)",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Expand",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                DropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    // Option 1: Default
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    text = "Default (Piper / espeak-ng)",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "স্ট্যান্ডার্ড মাল্টি-স্পিকার ভয়েস (দ্রুততম)",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        trailingIcon = {
                            if (selectedMode == DubbingVoiceMode.DEFAULT) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = EmeraldSuccess)
                            }
                        },
                        onClick = {
                            onSelectDefaultVoice()
                            expandedDropdown = false
                        },
                        modifier = Modifier.testTag("voice_option_default")
                    )

                    // Saved custom cloned voices
                    if (savedVoices.isNotEmpty()) {
                        savedVoices.forEach { voice ->
                            val isSelected = selectedMode == DubbingVoiceMode.CLONED && selectedVoiceId == voice.id
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = voice.name,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "কাস্টম রেফারেন্স অডিও (${voice.durationFormatted}) • XTTS-v2",
                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                trailingIcon = {
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = EmeraldSuccess)
                                    }
                                },
                                onClick = {
                                    onSelectCustomVoice(voice.id)
                                    expandedDropdown = false
                                },
                                modifier = Modifier.testTag("voice_option_${voice.id}")
                            )
                        }
                    }
                }
            }
        }

            // Status Note / Smart Guidance Warning Banner
            Spacer(modifier = Modifier.height(10.dp))
            if (selectedMode == DubbingVoiceMode.CLONED) {
                if (!targetLanguage.isXttsSupported) {
                    // Warning Banner: Target language is not supported by XTTS-v2
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("voice_cloning_unsupported_warning"),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Warning",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "⚠️ কণ্ঠ ক্লোনিং ${targetLanguage.displayNameBangla}-য় সাপোর্টেড নয়",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ভালো ফলাফলের জন্য Target Language ইংরেজি/হিন্দি করুন, অথবা Default Voice ব্যবহার করুন। Coqui XTTS-v2 মডেলের সরাসরি ক্রস-লিঙ্গুয়াল ক্লোনিং এই টার্গেট ভাষায় উপলব্ধ নয়।",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp, lineHeight = 16.sp),
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = onSwitchToEnglish,
                                    modifier = Modifier.testTag("switch_to_english_button"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = IndigoPrimary
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Translate,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Switch to English",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                                OutlinedButton(
                                    onClick = onSelectDefaultVoice,
                                    modifier = Modifier.testTag("switch_to_default_voice_button"),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "Default Voice রাখুন",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = EmeraldSuccess.copy(alpha = 0.12f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🎙️ XTTS-v2 মোড সক্রিয়: ${targetLanguage.displayNameEnglish}-এ কণ্ঠস্বর ক্লোন হবে (CPU মোডে কিছুটা বেশি সময় লাগতে পারে)।",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
