package com.example.ui.components

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.VoicePoolEntry
import com.example.model.VoicePoolManifest
import com.example.model.VoiceProfile
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimary

@Composable
fun VoiceLibraryDialog(
    savedVoices: List<VoiceProfile>,
    isUploading: Boolean,
    uploadError: String?,
    voicePoolManifest: VoicePoolManifest,
    isUploadingPool: Boolean = false,
    poolMessage: String? = null,
    onDismiss: () -> Unit,
    onUploadVoice: (name: String, uri: Uri, fileName: String) -> Unit,
    onDeleteVoice: (String) -> Unit,
    onUploadVoiceToPool: (uri: Uri, fileName: String) -> Unit = { _, _ -> },
    onDeleteVoiceFromPool: (VoicePoolEntry) -> Unit = {},
    onClearVoicePool: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTabIndex by remember { mutableIntStateOf(0) }

    // Tab 0 (Cloning profile) state
    var voiceNameInput by remember { mutableStateOf("") }
    var selectedAudioUri by remember { mutableStateOf<Uri?>(null) }
    var selectedAudioFileName by remember { mutableStateOf<String?>(null) }

    // Tab 1 (Voice Pool) state
    var selectedPoolAudioUri by remember { mutableStateOf<Uri?>(null) }
    var selectedPoolAudioFileName by remember { mutableStateOf<String?>(null) }
    var entryToDeleteFromPool by remember { mutableStateOf<VoicePoolEntry?>(null) }
    var showClearPoolConfirmDialog by remember { mutableStateOf(false) }

    val pickAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedAudioUri = uri
            selectedAudioFileName = queryFileName(context, uri) ?: "voice_sample.wav"
        }
    }

    val pickPoolAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedPoolAudioUri = uri
            selectedPoolAudioFileName = queryFileName(context, uri) ?: "pool_sample.wav"
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, IndigoPrimary.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                .testTag("voice_library_dialog"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(IndigoPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (selectedTabIndex == 0) Icons.Default.Mic else Icons.Default.Group,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ভয়েস ও স্পিকার লাইব্রেরি",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "কাস্টম ক্লোন ও মাল্টি-স্পিকার ভয়েস পুল",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_voice_library_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tabs: 0 -> কাস্টম ক্লোনড প্রোফাইল, 1 -> মাল্টি-স্পিকার ভয়েস পুল
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = {
                            Text(
                                "কাস্টম প্রোফাইল (${savedVoices.size}/5)",
                                fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = {
                            Text(
                                "ভয়েস পুল (${voicePoolManifest.voices.size})",
                                fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (selectedTabIndex == 0) {
                    // TAB 0: Custom Voice Cloning Profiles
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = IndigoPrimary.copy(alpha = 0.1f),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(CyanAccent.copy(alpha = 0.4f))
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Info",
                                tint = CyanAccent,
                                modifier = Modifier
                                    .size(20.dp)
                                    .padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "অডিও রেকর্ডিং নির্দেশিকা:",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = CyanAccent
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "কমপক্ষে ৬ সেকেন্ড এবং অনূর্ধ্ব ৬০ সেকেন্ড (২০-৩০ সেকেন্ডের নমুনা সর্বোত্তম), শান্ত পরিবেশে স্পষ্ট কণ্ঠে রেকর্ডকৃত অডিও দিন।",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp, lineHeight = 16.sp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "+ নতুন ক্লোনিং স্যাম্পল যোগ করুন",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = voiceNameInput,
                        onValueChange = { voiceNameInput = it },
                        label = { Text("ভয়েসের নাম (যেমন: আমার কণ্ঠ, উপস্থাপক)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("voice_name_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { pickAudioLauncher.launch("audio/*") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pick_audio_button"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.UploadFile,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedAudioFileName != null) "ফাইল নির্বাচিত" else "অডিও ফাইল বাছুন",
                                maxLines = 1
                            )
                        }

                        Button(
                            onClick = {
                                val uri = selectedAudioUri
                                if (uri != null && voiceNameInput.isNotBlank()) {
                                    onUploadVoice(
                                        voiceNameInput.trim(),
                                        uri,
                                        selectedAudioFileName ?: "voice.wav"
                                    )
                                    voiceNameInput = ""
                                    selectedAudioUri = null
                                    selectedAudioFileName = null
                                }
                            },
                            enabled = !isUploading && selectedAudioUri != null && voiceNameInput.isNotBlank() && savedVoices.size < 5,
                            modifier = Modifier.testTag("save_voice_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            if (isUploading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("আপলোড...")
                            } else {
                                Text("সেভ করুন")
                            }
                        }
                    }

                    if (selectedAudioFileName != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "নমুনা ফাইল: $selectedAudioFileName",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = EmeraldSuccess
                        )
                    }

                    if (uploadError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = uploadError,
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.error)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "সংরক্ষিত ভয়েস তালিকা (${savedVoices.size}/৫)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (savedVoices.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "এখনো কোনো কাস্টম ভয়েস সেভ করা নেই।",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            savedVoices.forEach { voice ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("saved_voice_item_${voice.id}"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(CircleShape)
                                                    .background(EmeraldSuccess.copy(alpha = 0.15f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Audiotrack,
                                                    contentDescription = null,
                                                    tint = EmeraldSuccess,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = voice.name,
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "দৈর্ঘ্য: ${voice.durationFormatted} • XTTS-v2 প্রস্তুত",
                                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        IconButton(
                                            onClick = { onDeleteVoice(voice.id) },
                                            modifier = Modifier.testTag("delete_voice_${voice.id}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete Voice",
                                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // TAB 1: Automatic Multi-Speaker Voice Pool
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = IndigoPrimary.copy(alpha = 0.1f),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(EmeraldSuccess.copy(alpha = 0.4f))
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = "Pool",
                                tint = EmeraldSuccess,
                                modifier = Modifier
                                    .size(20.dp)
                                    .padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Firebase Storage ভয়েস পুল:",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = EmeraldSuccess
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "সকল স্যাম্পল সরাসরি Firebase Storage-এ সংরক্ষিত হয়। ভিডিও অনুবাদের সময় Colab বা লোকাল সার্ভার এই স্যাম্পলগুলো ডাউনলোড করে প্রতিটি স্পিকারের জন্য আলাদা XTTS ভয়েস বরাদ্দ করবে।",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp, lineHeight = 16.sp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "+ পুলে নতুন ভয়েস স্যাম্পল আপলোড করুন",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { pickPoolAudioLauncher.launch("audio/*") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pick_pool_audio_button"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.UploadFile,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedPoolAudioFileName != null) "ফাইল নির্বাচিত" else "অডিও স্যাম্পল নির্বাচন",
                                maxLines = 1
                            )
                        }

                        Button(
                            onClick = {
                                val uri = selectedPoolAudioUri
                                if (uri != null) {
                                    onUploadVoiceToPool(
                                        uri,
                                        selectedPoolAudioFileName ?: "pool_voice.wav"
                                    )
                                    selectedPoolAudioUri = null
                                    selectedPoolAudioFileName = null
                                }
                            },
                            enabled = !isUploadingPool && selectedPoolAudioUri != null,
                            modifier = Modifier.testTag("upload_to_pool_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                        ) {
                            if (isUploadingPool) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("আপলোড...")
                            } else {
                                Text("পুলে যুক্ত করুন")
                            }
                        }
                    }

                    if (selectedPoolAudioFileName != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "নির্বাচিত: $selectedPoolAudioFileName",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = EmeraldSuccess
                        )
                    }

                    if (poolMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = poolMessage,
                            style = MaterialTheme.typography.bodySmall.copy(color = CyanAccent)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "পুলের ভয়েস তালিকা (${voicePoolManifest.voices.size}টি)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (voicePoolManifest.voices.isNotEmpty()) {
                            OutlinedButton(
                                onClick = { showClearPoolConfirmDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("clear_voice_pool_button")
                            ) {
                                Text("পুল রিসেট", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    if (voicePoolManifest.voices.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Firebase Storage পুলে এখনো কোনো ভয়েস নেই। উপরের ফর্ম দিয়ে স্যাম্পল আপলোড করুন।",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            voicePoolManifest.voices.forEachIndexed { index, entry ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("voice_pool_item_${entry.id}"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .clip(CircleShape)
                                                    .background(CyanAccent.copy(alpha = 0.2f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = "${index + 1}",
                                                    style = MaterialTheme.typography.labelMedium.copy(
                                                        fontWeight = FontWeight.Bold,
                                                        color = CyanAccent
                                                    )
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = entry.name.ifBlank { entry.id },
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "ফাইল: ${entry.fileName.ifBlank { entry.storagePath ?: "sample.wav" }}",
                                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.5.sp),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1
                                                )
                                            }
                                        }

                                        IconButton(
                                            onClick = { entryToDeleteFromPool = entry },
                                            modifier = Modifier.testTag("delete_pool_voice_${entry.id}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "মুছে ফেলুন",
                                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (entryToDeleteFromPool != null) {
                    val target = entryToDeleteFromPool!!
                    AlertDialog(
                        onDismissRequest = { entryToDeleteFromPool = null },
                        title = { Text("ভয়েস স্যাম্পল মুছে ফেলবেন?") },
                        text = { Text("এই ভয়েস স্যাম্পলটি মুছে ফেলতে চান? এটি ফিরিয়ে আনা যাবে না।") },
                        confirmButton = {
                            Button(
                                onClick = {
                                    onDeleteVoiceFromPool(target)
                                    entryToDeleteFromPool = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("হ্যাঁ, মুছে ফেলুন")
                            }
                        },
                        dismissButton = {
                            OutlinedButton(onClick = { entryToDeleteFromPool = null }) {
                                Text("বাতিল")
                            }
                        }
                    )
                }

                if (showClearPoolConfirmDialog) {
                    AlertDialog(
                        onDismissRequest = { showClearPoolConfirmDialog = false },
                        title = { Text("সম্পূর্ণ ভয়েস পুল রিসেট") },
                        text = { Text("আপনি কি নিশ্চিত যে সম্পূর্ণ ভয়েস পুল খালি করতে চান? Firebase Storage-এর সকল ভয়েস স্যাম্পল মুছে যাবে।") },
                        confirmButton = {
                            Button(
                                onClick = {
                                    onClearVoicePool()
                                    showClearPoolConfirmDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("হ্যাঁ, রিসেট করুন")
                            }
                        },
                        dismissButton = {
                            OutlinedButton(onClick = { showClearPoolConfirmDialog = false }) {
                                Text("বাতিল")
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("done_voice_library_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = "সম্পন্ন / বন্ধ করুন (Done)",
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

private fun queryFileName(context: Context, uri: Uri): String? {
    var name: String? = null
    try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) {
                    name = cursor.getString(index)
                }
            }
        }
    } catch (_: Exception) {}
    return name ?: uri.lastPathSegment
}
