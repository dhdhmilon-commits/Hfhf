package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Speaker
import com.example.model.SpeakerGender
import com.example.model.VoiceType
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.IndigoPrimary

@Composable
fun SpeakerListView(
    speakers: List<Speaker>,
    onUpdateSpeakerName: (String, String) -> Unit,
    onUpdateSpeakerGender: (String, SpeakerGender) -> Unit,
    onUpdateSpeakerVoice: (String, VoiceType) -> Unit,
    onUpdateSpeakerPitch: (String, Float) -> Unit,
    onUpdateSpeakerSpeed: (String, Float) -> Unit,
    onPlayVoicePreview: (Speaker) -> Unit,
    modifier: Modifier = Modifier
) {
    var editingSpeaker by remember { mutableStateOf<Speaker?>(null) }
    var tuningSpeaker by remember { mutableStateOf<Speaker?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("speaker_list_section")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.RecordVoiceOver,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Detected Speakers",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    ),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            Text(
                text = "${speakers.size} Speakers Identified",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        speakers.forEach { speaker ->
            SpeakerItemCard(
                speaker = speaker,
                onEditName = { editingSpeaker = speaker },
                onTuneVoice = { tuningSpeaker = speaker },
                onPlayPreview = { onPlayVoicePreview(speaker) }
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Rename Speaker Dialog
        editingSpeaker?.let { spk ->
            var tempName by remember(spk) { mutableStateOf(spk.displayName) }
            var tempGender by remember(spk) { mutableStateOf(spk.gender) }

            AlertDialog(
                onDismissRequest = { editingSpeaker = null },
                title = { Text("Edit Speaker Details") },
                text = {
                    Column {
                        Text(
                            text = "Customize speaker name and gender label:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = tempName,
                            onValueChange = { tempName = it },
                            label = { Text("Speaker Name (e.g. Rahim, Friend)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("speaker_name_input")
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Speaker Gender:",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = tempGender == SpeakerGender.MALE,
                                onClick = { tempGender = SpeakerGender.MALE },
                                label = { Text("Male") }
                            )
                            FilterChip(
                                selected = tempGender == SpeakerGender.FEMALE,
                                onClick = { tempGender = SpeakerGender.FEMALE },
                                label = { Text("Female") }
                            )
                            FilterChip(
                                selected = tempGender == SpeakerGender.UNKNOWN_NOT_CONFIDENT,
                                onClick = { tempGender = SpeakerGender.UNKNOWN_NOT_CONFIDENT },
                                label = { Text("Unknown") }
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onUpdateSpeakerName(spk.id, tempName)
                            onUpdateSpeakerGender(spk.id, tempGender)
                            editingSpeaker = null
                        }
                    ) {
                        Text("Save")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { editingSpeaker = null }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Voice Characteristics Tuning Dialog
        tuningSpeaker?.let { spk ->
            var tempVoice by remember(spk) { mutableStateOf(spk.selectedVoice) }
            var tempPitch by remember(spk) { mutableStateOf(spk.pitch) }
            var tempSpeed by remember(spk) { mutableStateOf(spk.speed) }

            AlertDialog(
                onDismissRequest = { tuningSpeaker = null },
                title = { Text("Voice Tuning: ${spk.displayName}") },
                text = {
                    Column {
                        Text(
                            text = "Select TTS Voice Type:",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = tempVoice == VoiceType.MALE_VOICE,
                                onClick = { tempVoice = VoiceType.MALE_VOICE },
                                label = { Text("Male") }
                            )
                            FilterChip(
                                selected = tempVoice == VoiceType.FEMALE_VOICE,
                                onClick = { tempVoice = VoiceType.FEMALE_VOICE },
                                label = { Text("Female") }
                            )
                            FilterChip(
                                selected = tempVoice == VoiceType.NEUTRAL_VOICE,
                                onClick = { tempVoice = VoiceType.NEUTRAL_VOICE },
                                label = { Text("Neutral") }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Pitch: ${String.format("%.2fx", tempPitch)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = tempPitch,
                            onValueChange = { tempPitch = it },
                            valueRange = 0.5f..2.0f
                        )

                        Text(
                            text = "Speech Rate: ${String.format("%.2fx", tempSpeed)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = tempSpeed,
                            onValueChange = { tempSpeed = it },
                            valueRange = 0.5f..1.5f
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                val testSpk = spk.copy(selectedVoice = tempVoice, pitch = tempPitch, speed = tempSpeed)
                                onPlayVoicePreview(testSpk)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Test Voice Preview")
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onUpdateSpeakerVoice(spk.id, tempVoice)
                            onUpdateSpeakerPitch(spk.id, tempPitch)
                            onUpdateSpeakerSpeed(spk.id, tempSpeed)
                            tuningSpeaker = null
                        }
                    ) {
                        Text("Apply Voice")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { tuningSpeaker = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun SpeakerItemCard(
    speaker: Speaker,
    onEditName: () -> Unit,
    onTuneVoice: () -> Unit,
    onPlayPreview: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("speaker_card_${speaker.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val (icon, tint) = when (speaker.gender) {
                        SpeakerGender.MALE -> Pair(Icons.Default.Male, IndigoPrimary)
                        SpeakerGender.FEMALE -> Pair(Icons.Default.Female, MaterialTheme.colorScheme.tertiary)
                        SpeakerGender.UNKNOWN_NOT_CONFIDENT -> Pair(Icons.AutoMirrored.Filled.HelpOutline, AmberWarning)
                    }

                    Surface(
                        shape = CircleShape,
                        color = tint.copy(alpha = 0.15f),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = icon,
                                contentDescription = speaker.gender.labelEnglish,
                                tint = tint,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = speaker.displayName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            IconButton(
                                onClick = onEditName,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Name",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Voice characteristic estimate label (not definitive gender)
                        Text(
                            text = speaker.genderEstimateLabel,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = if (speaker.gender == SpeakerGender.UNKNOWN_NOT_CONFIDENT) AmberWarning
                                else MaterialTheme.colorScheme.primary
                            )
                        )
                        Text(
                            text = "Estimated voice characteristic",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // Actions: Tune voice & Voice preview
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onTuneVoice,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Tune Voice",
                            tint = CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .clickable(onClick = onPlayPreview)
                            .testTag("preview_voice_${speaker.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Preview",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Voice",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metadata row: Track ID, Speaking time, Sentences
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Track: ${speaker.voiceTrackId}",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Time: ${speaker.totalSpeakingTimeMs / 1000}s",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${speaker.sentenceCount} Sentences",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
