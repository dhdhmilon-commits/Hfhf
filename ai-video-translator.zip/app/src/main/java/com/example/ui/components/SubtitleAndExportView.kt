package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExportAudioOption
import com.example.model.ExportFormat
import com.example.model.SubtitleLanguageOption
import com.example.model.VideoQuality
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimary

@Composable
fun SubtitleAndExportView(
    showOriginalSubtitle: Boolean,
    showTranslatedSubtitle: Boolean,
    showSpeakerName: Boolean,
    showTimestamp: Boolean,
    subtitleLanguageOption: SubtitleLanguageOption,
    onToggleOriginalSubtitle: (Boolean) -> Unit,
    onToggleTranslatedSubtitle: (Boolean) -> Unit,
    onToggleSpeakerName: (Boolean) -> Unit,
    onToggleTimestamp: (Boolean) -> Unit,
    onSetSubtitleLanguage: (SubtitleLanguageOption) -> Unit,
    voicePreservationConsentGranted: Boolean,
    onSetVoiceConsent: (Boolean) -> Unit,
    selectedExportFormat: ExportFormat,
    selectedQuality: VideoQuality,
    selectedAudioOption: ExportAudioOption,
    onSetExportFormat: (ExportFormat) -> Unit,
    onSetVideoQuality: (VideoQuality) -> Unit,
    onSetAudioOption: (ExportAudioOption) -> Unit,
    isProcessing: Boolean,
    onExportClicked: () -> Unit,
    onExportSubtitlesOnly: (ExportFormat) -> Unit,
    modifier: Modifier = Modifier
) {
    var showConsentDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("subtitle_export_section")
    ) {
        // --- 11. Subtitle Options Section ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(14.dp),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Subtitles,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Subtitle Configuration",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Checkbox Options
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SubtitleCheckboxItem(
                        label = "Original Subtitle",
                        checked = showOriginalSubtitle,
                        onCheckedChange = onToggleOriginalSubtitle,
                        modifier = Modifier.weight(1f)
                    )
                    SubtitleCheckboxItem(
                        label = "Translated Subtitle",
                        checked = showTranslatedSubtitle,
                        onCheckedChange = onToggleTranslatedSubtitle,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SubtitleCheckboxItem(
                        label = "Speaker Name",
                        checked = showSpeakerName,
                        onCheckedChange = onToggleSpeakerName,
                        modifier = Modifier.weight(1f)
                    )
                    SubtitleCheckboxItem(
                        label = "Timestamp",
                        checked = showTimestamp,
                        onCheckedChange = onToggleTimestamp,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))

                // Subtitle Language chips
                Text(
                    text = "Subtitle Language Display:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = subtitleLanguageOption == SubtitleLanguageOption.ORIGINAL_LANGUAGE,
                        onClick = { onSetSubtitleLanguage(SubtitleLanguageOption.ORIGINAL_LANGUAGE) },
                        label = { Text("Original (মূল)") }
                    )
                    FilterChip(
                        selected = subtitleLanguageOption == SubtitleLanguageOption.TARGET_LANGUAGE,
                        onClick = { onSetSubtitleLanguage(SubtitleLanguageOption.TARGET_LANGUAGE) },
                        label = { Text("Target (অনূদিত)") }
                    )
                    FilterChip(
                        selected = subtitleLanguageOption == SubtitleLanguageOption.BOTH,
                        onClick = { onSetSubtitleLanguage(SubtitleLanguageOption.BOTH) },
                        label = { Text("Both (দ্বিভাষিক)") }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Direct Subtitle Export buttons (SRT / VTT)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { onExportSubtitlesOnly(ExportFormat.SRT_SUBTITLE) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export SRT")
                    }
                    OutlinedButton(
                        onClick = { onExportSubtitlesOnly(ExportFormat.VTT_SUBTITLE) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export VTT")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- 8. Voice Preservation & Consent Section ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(14.dp),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Voice Preservation & Cloning",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Match original speaker pitch & cadence",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Switch(
                        checked = voicePreservationConsentGranted,
                        onCheckedChange = { granted ->
                            if (granted) {
                                showConsentDialog = true
                            } else {
                                onSetVoiceConsent(false)
                            }
                        }
                    )
                }

                if (voicePreservationConsentGranted) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(EmeraldSuccess.copy(alpha = 0.1f))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Legal user consent confirmed for voice preservation.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = EmeraldSuccess)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- 12. Final Export Section ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(14.dp),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VideoFile,
                        contentDescription = null,
                        tint = IndigoPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Export Settings",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Format selection
                Text(text = "Export Format:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedExportFormat == ExportFormat.MP4_VIDEO,
                        onClick = { onSetExportFormat(ExportFormat.MP4_VIDEO) },
                        label = { Text("MP4 Video") }
                    )
                    FilterChip(
                        selected = selectedExportFormat == ExportFormat.AUDIO_ONLY,
                        onClick = { onSetExportFormat(ExportFormat.AUDIO_ONLY) },
                        label = { Text("Audio Only") }
                    )
                    FilterChip(
                        selected = selectedExportFormat == ExportFormat.TRANSCRIPT_TXT,
                        onClick = { onSetExportFormat(ExportFormat.TRANSCRIPT_TXT) },
                        label = { Text("Transcript TXT") }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Video Quality selection
                Text(text = "Video Quality:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedQuality == VideoQuality.QUALITY_720P,
                        onClick = { onSetVideoQuality(VideoQuality.QUALITY_720P) },
                        label = { Text("720p HD") }
                    )
                    FilterChip(
                        selected = selectedQuality == VideoQuality.QUALITY_1080P,
                        onClick = { onSetVideoQuality(VideoQuality.QUALITY_1080P) },
                        label = { Text("1080p FHD") }
                    )
                    FilterChip(
                        selected = selectedQuality == VideoQuality.ORIGINAL,
                        onClick = { onSetVideoQuality(VideoQuality.ORIGINAL) },
                        label = { Text("Original") }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Audio Track Options
                Text(text = "Audio Options:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedAudioOption == ExportAudioOption.ORIGINAL_AUDIO,
                        onClick = { onSetAudioOption(ExportAudioOption.ORIGINAL_AUDIO) },
                        label = { Text("Original") }
                    )
                    FilterChip(
                        selected = selectedAudioOption == ExportAudioOption.TRANSLATED_AUDIO,
                        onClick = { onSetAudioOption(ExportAudioOption.TRANSLATED_AUDIO) },
                        label = { Text("Translated") }
                    )
                    FilterChip(
                        selected = selectedAudioOption == ExportAudioOption.BOTH_AUDIO,
                        onClick = { onSetAudioOption(ExportAudioOption.BOTH_AUDIO) },
                        label = { Text("Dual Track") }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // BIG EXPORT BUTTON
                Button(
                    onClick = onExportClicked,
                    enabled = !isProcessing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("export_video_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldSuccess
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Rendering & Packaging Export...")
                    } else {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "⬇ Export Video",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Voice Cloning Legal Consent Dialog
        if (showConsentDialog) {
            AlertDialog(
                onDismissRequest = { showConsentDialog = false },
                icon = {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = AmberWarning)
                },
                title = { Text("Voice Cloning Consent & Authorization") },
                text = {
                    Column {
                        Text(
                            text = "You are requesting to preserve and synthesize voice characteristics resembling the original speakers in this video.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Please confirm that you own the rights or have explicit authorization from all recorded speakers to use and translate their voice.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onSetVoiceConsent(true)
                            showConsentDialog = false
                        }
                    ) {
                        Text("I Agree & Confirm")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            onSetVoiceConsent(false)
                            showConsentDialog = false
                        }
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun SubtitleCheckboxItem(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.size(36.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, style = MaterialTheme.typography.bodySmall)
    }
}
