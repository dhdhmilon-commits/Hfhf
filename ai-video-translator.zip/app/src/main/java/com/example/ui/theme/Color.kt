package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimary = Color(0xFF6366F1)
val IndigoPrimaryDark = Color(0xFF818CF8)
val CyanAccent = Color(0xFF06B6D4)
val CyanAccentDark = Color(0xFF22D3EE)
val VioletTertiary = Color(0xFF8B5CF6)
val VioletTertiaryDark = Color(0xFFA78BFA)

val BackgroundDark = Color(0xFF0B0F19)
val SurfaceDark = Color(0xFF111827)
val SurfaceVariantDark = Color(0xFF1F2937)
val CardBorderDark = Color(0xFF374151)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val CardBorderLight = Color(0xFFE2E8F0)

val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFF43F5E)

