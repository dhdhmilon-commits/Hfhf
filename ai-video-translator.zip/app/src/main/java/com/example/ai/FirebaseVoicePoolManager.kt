package com.example.ai

import android.content.ContentResolver
import android.net.Uri
import com.example.model.VoicePoolEntry
import com.example.model.VoicePoolManifest
import com.google.firebase.FirebaseApp
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageException
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.UUID

/**
 * Manages the Voice Pool directly in Firebase Storage.
 *
 * All voice sample audio files are stored under `voice_pool/{timestamp}_{filename}`.
 * The pool manifest is maintained at `voice_pool/manifest.json`.
 *
 * Backend dubbing servers read this manifest directly via public download URL.
 */
class FirebaseVoicePoolManager {

    private val manifestPath = "voice_pool/manifest.json"

    private fun getStorage(): FirebaseStorage {
        val app = try {
            FirebaseApp.getInstance()
        } catch (e: Exception) {
            null
        }
        if (app == null) {
            throw IllegalStateException(
                "Firebase ইনিশিয়ালাইজ করা যায়নি। অনুগ্রহ করে app/ ফোল্ডারে google-services.json ফাইলটি যুক্ত করুন।"
            )
        }
        return FirebaseStorage.getInstance(app)
    }

    /**
     * Reads and parses voice_pool/manifest.json directly from Firebase Storage.
     */
    suspend fun getVoicePoolManifest(): VoicePoolManifest = withContext(Dispatchers.IO) {
        val storage = getStorage()
        val manifestRef = storage.reference.child(manifestPath)
        try {
            // Download up to 2MB for manifest JSON
            val bytes = manifestRef.getBytes(2 * 1024 * 1024).await()
            val jsonStr = String(bytes, Charsets.UTF_8)
            parseManifestJson(jsonStr)
        } catch (e: StorageException) {
            if (e.errorCode == StorageException.ERROR_OBJECT_NOT_FOUND) {
                // Not yet created, return empty manifest
                VoicePoolManifest(
                    version = "1.0",
                    description = "Firebase Voice Pool",
                    voices = emptyList()
                )
            } else {
                throw formatStorageError(e, "ম্যানিফেস্ট লোড করতে ব্যর্থ")
            }
        } catch (e: Exception) {
            if (e is IllegalStateException) throw e
            throw IOException("ভয়েস পুল ম্যানিফেস্ট রিড ব্যর্থ: ${e.localizedMessage}", e)
        }
    }

    /**
     * Uploads an audio sample to Firebase Storage under `voice_pool/{timestamp}_{filename}`,
     * retrieves its public download URL, and updates `voice_pool/manifest.json`.
     */
    suspend fun uploadVoiceSample(
        audioUri: Uri,
        fileName: String,
        contentResolver: ContentResolver
    ): VoicePoolEntry = withContext(Dispatchers.IO) {
        val storage = getStorage()

        // 1. Read audio bytes
        val inputStream = contentResolver.openInputStream(audioUri)
            ?: throw IOException("অডিও ফাইলটি ওপেন করা সম্ভব হয়নি: $fileName")
        val audioBytes = inputStream.use { it.readBytes() }
        if (audioBytes.isEmpty()) {
            throw IOException("অডিও ফাইলটি ফাঁকা (0 bytes)।")
        }

        // 2. Upload to Firebase Storage
        val cleanName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val timestamp = System.currentTimeMillis()
        val storageObjectPath = "voice_pool/${timestamp}_${cleanName}"
        val fileRef = storage.reference.child(storageObjectPath)

        val mimeType = contentResolver.getType(audioUri) ?: "audio/wav"
        val metadata = StorageMetadata.Builder()
            .setContentType(mimeType)
            .setCustomMetadata("originalName", fileName)
            .build()

        try {
            fileRef.putBytes(audioBytes, metadata).await()
        } catch (e: Exception) {
            throw formatStorageError(e, "ভয়েস স্যাম্পল আপলোড ব্যর্থ হয়েছে")
        }

        // 3. Get download URL
        val downloadUrl = try {
            fileRef.downloadUrl.await().toString()
        } catch (e: Exception) {
            throw formatStorageError(e, "ডাউনলোড লিঙ্ক তৈরি করতে ব্যর্থ")
        }

        // 4. Fetch current manifest and append new entry
        val currentManifest = try {
            getVoicePoolManifest()
        } catch (_: Exception) {
            VoicePoolManifest(version = "1.0", description = "Firebase Voice Pool", voices = emptyList())
        }

        val entryId = UUID.randomUUID().toString()
        val newEntry = VoicePoolEntry(
            id = entryId,
            name = fileName.substringBeforeLast('.').ifBlank { "Voice ${currentManifest.voices.size + 1}" },
            gender = "unknown",
            language = "auto",
            storagePath = storageObjectPath,
            downloadUrl = downloadUrl,
            url = downloadUrl,
            addedAt = timestamp,
            fileName = fileName
        )

        val updatedVoices = currentManifest.voices + newEntry
        val updatedManifest = currentManifest.copy(voices = updatedVoices)

        // 5. Save updated manifest.json to Firebase Storage
        saveManifest(storage.reference.child(manifestPath), updatedManifest)

        newEntry
    }

    /**
     * Deletes a single voice sample object from Firebase Storage and removes its record
     * from `voice_pool/manifest.json`.
     */
    suspend fun deleteVoiceSample(entry: VoicePoolEntry): VoicePoolManifest = withContext(Dispatchers.IO) {
        val storage = getStorage()

        // 1. Delete storage file object if path or URL is known
        try {
            if (!entry.storagePath.isNullOrBlank()) {
                storage.reference.child(entry.storagePath).delete().await()
            } else if (entry.url.isNotBlank() && entry.url.startsWith("https://firebasestorage.googleapis.com")) {
                storage.getReferenceFromUrl(entry.url).delete().await()
            }
        } catch (e: StorageException) {
            // If already deleted or not found, proceed to manifest update
            if (e.errorCode != StorageException.ERROR_OBJECT_NOT_FOUND) {
                // Log or continue
            }
        } catch (_: Exception) {}

        // 2. Update manifest
        val currentManifest = getVoicePoolManifest()
        val updatedVoices = currentManifest.voices.filter { it.id != entry.id && it.url != entry.url }
        val updatedManifest = currentManifest.copy(voices = updatedVoices)

        saveManifest(storage.reference.child(manifestPath), updatedManifest)
        updatedManifest
    }

    /**
     * Clears all voice samples under `voice_pool/` and resets `voice_pool/manifest.json`.
     */
    suspend fun clearVoicePool(): VoicePoolManifest = withContext(Dispatchers.IO) {
        val storage = getStorage()
        val poolRef = storage.reference.child("voice_pool")

        // 1. Delete all items in voice_pool/
        try {
            val listResult = poolRef.listAll().await()
            for (item in listResult.items) {
                try {
                    item.delete().await()
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            // Proceed to save empty manifest even if listAll fails or is restricted
        }

        // 2. Upload fresh empty manifest
        val emptyManifest = VoicePoolManifest(
            version = "1.0",
            description = "Firebase Voice Pool",
            voices = emptyList()
        )
        saveManifest(storage.reference.child(manifestPath), emptyManifest)
        emptyManifest
    }

    /**
     * Retrieves the public download URL of `voice_pool/manifest.json`.
     * If the manifest does not exist yet in Firebase Storage, it initializes an empty one first.
     */
    suspend fun getManifestDownloadUrl(): String = withContext(Dispatchers.IO) {
        val storage = getStorage()
        val manifestRef = storage.reference.child(manifestPath)
        try {
            manifestRef.downloadUrl.await().toString()
        } catch (e: StorageException) {
            if (e.errorCode == StorageException.ERROR_OBJECT_NOT_FOUND) {
                val emptyManifest = VoicePoolManifest(
                    version = "1.0",
                    description = "Firebase Voice Pool",
                    voices = emptyList()
                )
                saveManifest(manifestRef, emptyManifest)
                manifestRef.downloadUrl.await().toString()
            } else {
                throw formatStorageError(e, "ম্যানিফেস্ট ডাউনলোড লিঙ্ক পেতে ব্যর্থ")
            }
        }
    }

    private suspend fun saveManifest(manifestRef: StorageReference, manifest: VoicePoolManifest) {
        val jsonObj = JSONObject().apply {
            put("version", manifest.version)
            put("description", manifest.description)
            val array = JSONArray()
            for (v in manifest.voices) {
                val vObj = JSONObject().apply {
                    put("id", v.id)
                    put("name", v.name)
                    put("gender", v.gender)
                    put("language", v.language)
                    put("storagePath", v.storagePath ?: "")
                    put("downloadUrl", v.downloadUrl ?: v.url)
                    put("url", v.url)
                    put("addedAt", v.addedAt)
                    put("fileName", v.fileName)
                }
                array.put(vObj)
            }
            put("voices", array)
        }

        val jsonBytes = jsonObj.toString(2).toByteArray(Charsets.UTF_8)
        val meta = StorageMetadata.Builder()
            .setContentType("application/json")
            .setCacheControl("no-cache, max-age=0")
            .build()

        try {
            manifestRef.putBytes(jsonBytes, meta).await()
        } catch (e: Exception) {
            throw formatStorageError(e, "ম্যানিফেস্ট আপডেট সেভ করতে ব্যর্থ")
        }
    }

    private fun parseManifestJson(jsonString: String): VoicePoolManifest {
        val json = JSONObject(jsonString)
        val version = json.optString("version", "1.0")
        val description = json.optString("description", "Firebase Voice Pool")
        val voicesArray = json.optJSONArray("voices") ?: JSONArray()
        val voicesList = mutableListOf<VoicePoolEntry>()

        for (i in 0 until voicesArray.length()) {
            val item = voicesArray.optJSONObject(i)
            if (item != null) {
                val url = item.optString("url", "").ifBlank { item.optString("downloadUrl", "") }
                if (url.isNotBlank()) {
                    voicesList.add(
                        VoicePoolEntry(
                            id = item.optString("id", UUID.randomUUID().toString()),
                            name = item.optString("name", item.optString("fileName", "Voice ${i + 1}")),
                            gender = item.optString("gender", "unknown"),
                            language = item.optString("language", "auto"),
                            storagePath = item.optString("storagePath", "").ifBlank { null },
                            downloadUrl = item.optString("downloadUrl", url),
                            url = url,
                            addedAt = item.optLong("addedAt", System.currentTimeMillis()),
                            fileName = item.optString("fileName", "")
                        )
                    )
                }
            }
        }

        return VoicePoolManifest(
            version = version,
            description = description,
            voices = voicesList
        )
    }

    private fun formatStorageError(e: Exception, contextMsg: String): Exception {
        if (e is StorageException) {
            val banglaMsg = when (e.errorCode) {
                StorageException.ERROR_NOT_AUTHORIZED ->
                    "Firebase Storage অ্যাক্সেস অনুমোদিত নয় (Permission Denied)। অনুগ্রহ করে Firebase Console থেকে Storage Rules-এ read/write পারমিশন চালু করুন।"
                StorageException.ERROR_OBJECT_NOT_FOUND ->
                    "Firebase Storage-এ ফাইলটি পাওয়া যায়নি।"
                StorageException.ERROR_RETRY_LIMIT_EXCEEDED,
                StorageException.ERROR_UNKNOWN ->
                    "Firebase Storage সংযোগ ব্যর্থ হয়েছে। ইন্টারনেট সংযোগ চেক করুন এবং পুনরায় চেষ্টা করুন।"
                StorageException.ERROR_QUOTA_EXCEEDED ->
                    "Firebase Storage কোটা অতিক্রম করেছে।"
                else ->
                    "Firebase Storage ত্রুটি (Code ${e.errorCode}): ${e.localizedMessage}"
            }
            return IOException("$contextMsg: $banglaMsg", e)
        }
        return IOException("$contextMsg: ${e.localizedMessage ?: e.message}", e)
    }
}
