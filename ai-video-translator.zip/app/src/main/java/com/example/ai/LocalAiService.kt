package com.example.ai

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import com.example.model.DialogueSegment
import com.example.model.JobQueueStatus
import com.example.model.LocalServerHardwareInfo
import com.example.model.Speaker
import com.example.model.SpeakerGender
import com.example.model.SupportedLanguage
import com.example.model.VoiceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class BackendJobProgress(
    val jobId: String,
    val status: String,
    val currentStep: String,
    val progressPercent: Int,
    val statusMessage: String,
    val errorMessage: String? = null
)

class LocalServerOfflineException(val serverUrl: String, cause: Throwable? = null) : Exception(
    "স্থানীয় AI ব্যাকএন্ড সার্ভারের সাথে সংযোগ করা সম্ভব হয়নি ($serverUrl)!\n\n" +
    "দয়া করে নিশ্চিত করুন:\n" +
    "১. আপনার কম্পিউটারে './run_backend.sh' বা 'python main.py' চালু আছে।\n" +
    "২. সার্ভার URL ঠিক আছে (যেমন 'http://10.0.2.2:8000')।\n\n" +
    "এই অ্যাপে কোনো ক্লাউড বা পেইড এপিআই ব্যবহার করা হয় না। সমস্ত প্রসেসিং আপনার লোকাল সার্ভারে সম্পন্ন হয়।",
    cause
)

interface AiTranslationProvider {
    suspend fun checkLocalServerHealth(serverUrl: String): LocalServerHardwareInfo

    suspend fun submitVideoJob(
        serverUrl: String,
        videoBytes: ByteArray,
        fileName: String,
        sourceLang: String,
        targetLang: String,
        voiceMode: String = "default",
        customVoiceId: String? = null,
        useVoicePool: Boolean = false,
        voicePoolManifestUrl: String? = null
    ): String

    suspend fun submitVideoJobStream(
        serverUrl: String,
        videoUri: Uri,
        contentResolver: ContentResolver,
        fileName: String,
        sourceLang: String,
        targetLang: String,
        voiceMode: String = "default",
        customVoiceId: String? = null,
        useVoicePool: Boolean = false,
        voicePoolManifestUrl: String? = null,
        onProgress: ((Int) -> Unit)? = null
    ): String

    suspend fun getVoiceProfiles(serverUrl: String): List<com.example.model.VoiceProfile>

    suspend fun uploadVoiceProfile(
        serverUrl: String,
        name: String,
        audioUri: Uri,
        contentResolver: ContentResolver,
        fileName: String
    ): com.example.model.VoiceProfile

    suspend fun deleteVoiceProfile(
        serverUrl: String,
        voiceId: String
    ): Boolean

    suspend fun getJobStatus(
        serverUrl: String,
        jobId: String
    ): BackendJobProgress

    suspend fun getJobResult(
        serverUrl: String,
        jobId: String
    ): Pair<List<Speaker>, List<DialogueSegment>>

    suspend fun downloadExportFile(
        serverUrl: String,
        jobId: String,
        format: String
    ): ByteArray
}

class LocalAiService : AiTranslationProvider {

    // Status queries & health checks client
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    // Dedicated upload & large file transfer client (30-min timeout for large 20-min video files)
    private val transferHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.MINUTES)
        .readTimeout(30, TimeUnit.MINUTES)
        .build()

    override suspend fun checkLocalServerHealth(serverUrl: String): LocalServerHardwareInfo = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        try {
            val request = Request.Builder()
                .url("$cleanUrl/health")
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val json = JSONObject(body)
                    val gpuAvailable = json.optBoolean("gpu_available", false)
                    val gpuName = json.optString("gpu_name", if (gpuAvailable) "NVIDIA CUDA GPU" else "CPU Mode")
                    val modelsObj = json.optJSONObject("models")

                    return@withContext LocalServerHardwareInfo(
                        isServerConnected = true,
                        serverUrl = cleanUrl,
                        gpuAvailable = gpuAvailable,
                        gpuName = gpuName,
                        executionMode = if (gpuAvailable) "Local GPU (CUDA) Mode" else "Local CPU Mode",
                        cpuCores = json.optInt("cpu_cores", 8),
                        ramAvailableGb = json.optDouble("available_ram_gb", 12.0).toFloat(),
                        sttModel = modelsObj?.optString("stt") ?: "Faster-Whisper (Local)",
                        diarizationModel = modelsObj?.optString("diarization") ?: "Acoustic Diarization & Voice Timbre (Local)",
                        translationModel = modelsObj?.optString("translation") ?: "MarianMT / NLLB-200 (Local)",
                        ttsModel = modelsObj?.optString("tts") ?: "Piper Neural TTS (Local)",
                        ffmpegStatus = modelsObj?.optString("ffmpeg") ?: "Local FFmpeg / FFprobe",
                        speedFactor = json.optString("estimated_speed", if (gpuAvailable) "1.8x real-time (CUDA)" else "0.8x real-time (CPU)")
                    )
                }
            }
        } catch (_: Exception) {
            // Server not reachable
        }

        // Return honest offline status — NEVER fake an on-device local engine
        return@withContext LocalServerHardwareInfo(
            isServerConnected = false,
            serverUrl = cleanUrl,
            gpuAvailable = false,
            gpuName = "সার্ভার সংযোগ বিচ্ছিন্ন (Not Connected)",
            executionMode = "সার্ভার অফলাইন (Offline - Run ./run_backend.sh)",
            speedFactor = "N/A"
        )
    }

    override suspend fun submitVideoJob(
        serverUrl: String,
        videoBytes: ByteArray,
        fileName: String,
        sourceLang: String,
        targetLang: String,
        voiceMode: String,
        customVoiceId: String?,
        useVoicePool: Boolean,
        voicePoolManifestUrl: String?
    ): String = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        try {
            val mediaType = "video/*".toMediaType()
            val requestBuilder = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    "video",
                    fileName,
                    videoBytes.toRequestBody(mediaType)
                )
                .addFormDataPart("source_lang", sourceLang)
                .addFormDataPart("target_lang", targetLang)
                .addFormDataPart("voice_mode", voiceMode)
                .addFormDataPart("use_voice_pool", useVoicePool.toString())

            if (!customVoiceId.isNullOrBlank()) {
                requestBuilder.addFormDataPart("custom_voice_id", customVoiceId)
            }
            if (!voicePoolManifestUrl.isNullOrBlank()) {
                requestBuilder.addFormDataPart("voice_pool_manifest_url", voicePoolManifestUrl)
            }

            val requestBody = requestBuilder.build()
            val request = Request.Builder()
                .url("$cleanUrl/api/jobs/create")
                .post(requestBody)
                .build()

            transferHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: "HTTP ${response.code}"
                    throw IOException("সার্ভার থেকে এরর রেসপন্স এসেছে: $errBody")
                }

                val body = response.body?.string() ?: throw IOException("Empty response from backend")
                val json = JSONObject(body)
                val jobId = json.optString("job_id")
                if (jobId.isBlank()) {
                    throw IOException("Job ID not returned by server")
                }
                return@withContext jobId
            }
        } catch (e: IOException) {
            throw LocalServerOfflineException(cleanUrl, e)
        }
    }

    override suspend fun submitVideoJobStream(
        serverUrl: String,
        videoUri: Uri,
        contentResolver: ContentResolver,
        fileName: String,
        sourceLang: String,
        targetLang: String,
        voiceMode: String,
        customVoiceId: String?,
        useVoicePool: Boolean,
        voicePoolManifestUrl: String?,
        onProgress: ((Int) -> Unit)?
    ): String = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        try {
            val fileDescriptor = try {
                contentResolver.openFileDescriptor(videoUri, "r")
            } catch (_: Exception) {
                null
            }
            val totalBytes = fileDescriptor?.statSize ?: -1L
            fileDescriptor?.close()

            val mediaType = "video/*".toMediaType()
            val streamingBody = object : RequestBody() {
                override fun contentType() = mediaType
                override fun contentLength() = totalBytes

                override fun writeTo(sink: BufferedSink) {
                    val inputStream = contentResolver.openInputStream(videoUri)
                        ?: throw IOException("ভিডিও ফাইলটি রিড করা সম্ভব হয়নি ($videoUri)")
                    inputStream.use { stream ->
                        val buffer = ByteArray(64 * 1024)
                        var bytesRead: Int
                        var uploaded = 0L
                        while (stream.read(buffer).also { bytesRead = it } != -1) {
                            sink.write(buffer, 0, bytesRead)
                            uploaded += bytesRead
                            if (totalBytes > 0 && onProgress != null) {
                                val pct = ((uploaded * 100) / totalBytes).toInt().coerceIn(0, 100)
                                onProgress(pct)
                            }
                        }
                    }
                }
            }

            val requestBuilder = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("video", fileName, streamingBody)
                .addFormDataPart("source_lang", sourceLang)
                .addFormDataPart("target_lang", targetLang)
                .addFormDataPart("voice_mode", voiceMode)
                .addFormDataPart("use_voice_pool", useVoicePool.toString())

            if (!customVoiceId.isNullOrBlank()) {
                requestBuilder.addFormDataPart("custom_voice_id", customVoiceId)
            }
            if (!voicePoolManifestUrl.isNullOrBlank()) {
                requestBuilder.addFormDataPart("voice_pool_manifest_url", voicePoolManifestUrl)
            }

            val requestBody = requestBuilder.build()

            val request = Request.Builder()
                .url("$cleanUrl/api/jobs/create")
                .post(requestBody)
                .build()

            transferHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: "HTTP ${response.code}"
                    throw IOException("সার্ভার থেকে এরর রেসপন্স এসেছে: $errBody")
                }

                val body = response.body?.string() ?: throw IOException("Empty response from backend")
                val json = JSONObject(body)
                val jobId = json.optString("job_id")
                if (jobId.isBlank()) {
                    throw IOException("Job ID not returned by server")
                }
                return@withContext jobId
            }
        } catch (e: IOException) {
            throw LocalServerOfflineException(cleanUrl, e)
        }
    }

    override suspend fun getVoiceProfiles(serverUrl: String): List<com.example.model.VoiceProfile> = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        try {
            val request = Request.Builder()
                .url("$cleanUrl/api/voices")
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext emptyList()
                val body = response.body?.string() ?: return@withContext emptyList()
                val jsonArr = JSONArray(body)
                val list = mutableListOf<com.example.model.VoiceProfile>()
                for (i in 0 until jsonArr.length()) {
                    val obj = jsonArr.getJSONObject(i)
                    list.add(
                        com.example.model.VoiceProfile(
                            id = obj.optString("id"),
                            name = obj.optString("name"),
                            durationSec = obj.optDouble("duration_sec", 0.0).toFloat(),
                            durationFormatted = obj.optString("duration_formatted", "00:00"),
                            createdAt = (obj.optDouble("created_at", 0.0) * 1000).toLong(),
                            isReady = obj.optBoolean("is_ready", true)
                        )
                    )
                }
                return@withContext list
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    override suspend fun uploadVoiceProfile(
        serverUrl: String,
        name: String,
        audioUri: Uri,
        contentResolver: ContentResolver,
        fileName: String
    ): com.example.model.VoiceProfile = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        val inputStream = contentResolver.openInputStream(audioUri)
            ?: throw IOException("অডিও ফাইলটি ওপেন করা সম্ভব হয়নি")
        val audioBytes = inputStream.use { it.readBytes() }
        val mediaType = "audio/*".toMediaType()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("name", name)
            .addFormDataPart("file", fileName, audioBytes.toRequestBody(mediaType))
            .build()

        val request = Request.Builder()
            .url("$cleanUrl/api/voices")
            .post(requestBody)
            .build()

        transferHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val err = response.body?.string() ?: "HTTP ${response.code}"
                throw IOException("ভয়েস আপলোড ব্যর্থ হয়েছে: $err")
            }
            val body = response.body?.string() ?: throw IOException("Empty response from backend")
            val obj = JSONObject(body)
            return@withContext com.example.model.VoiceProfile(
                id = obj.optString("id"),
                name = obj.optString("name"),
                durationSec = obj.optDouble("duration_sec", 0.0).toFloat(),
                durationFormatted = obj.optString("duration_formatted", "00:00"),
                createdAt = (obj.optDouble("created_at", 0.0) * 1000).toLong(),
                isReady = true
            )
        }
    }

    override suspend fun deleteVoiceProfile(
        serverUrl: String,
        voiceId: String
    ): Boolean = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        try {
            val request = Request.Builder()
                .url("$cleanUrl/api/voices/$voiceId")
                .delete()
                .build()

            httpClient.newCall(request).execute().use { response ->
                return@withContext response.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    override suspend fun getJobStatus(
        serverUrl: String,
        jobId: String
    ): BackendJobProgress = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        try {
            val request = Request.Builder()
                .url("$cleanUrl/api/jobs/$jobId/status")
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Status request failed: HTTP ${response.code}")
                }
                val body = response.body?.string() ?: ""
                val json = JSONObject(body)
                return@withContext BackendJobProgress(
                    jobId = json.optString("job_id", jobId),
                    status = json.optString("status", "PROCESSING"),
                    currentStep = json.optString("current_step", "PROCESSING"),
                    progressPercent = json.optInt("progress_percent", 0),
                    statusMessage = json.optString("status_message", ""),
                    errorMessage = if (json.has("error_message") && !json.isNull("error_message")) json.getString("error_message") else null
                )
            }
        } catch (e: IOException) {
            throw LocalServerOfflineException(cleanUrl, e)
        }
    }

    override suspend fun getJobResult(
        serverUrl: String,
        jobId: String
    ): Pair<List<Speaker>, List<DialogueSegment>> = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        try {
            val request = Request.Builder()
                .url("$cleanUrl/api/jobs/$jobId/result")
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Result request failed: HTTP ${response.code}")
                }
                val body = response.body?.string() ?: ""
                val json = JSONObject(body)

                // 1. Parse Speakers
                val speakersList = mutableListOf<Speaker>()
                val spkArray = json.optJSONArray("speakers") ?: JSONArray()
                for (i in 0 until spkArray.length()) {
                    val sObj = spkArray.getJSONObject(i)
                    val genderStr = sObj.optString("gender", "UNKNOWN_NOT_CONFIDENT")
                    val gender = when (genderStr) {
                        "MALE" -> SpeakerGender.MALE
                        "FEMALE" -> SpeakerGender.FEMALE
                        else -> SpeakerGender.UNKNOWN_NOT_CONFIDENT
                    }
                    val genderConf = sObj.optDouble("genderConfidence", 0.85).toFloat()
                    val id = sObj.optString("id", "spk_${i + 1}")
                    val defaultName = sObj.optString("defaultName", "Speaker ${i + 1}")
                    val customName = sObj.optString("customName", "")
                    val speakingTime = sObj.optLong("speakingTimeMs", 0L)
                    val sentenceCount = sObj.optInt("sentenceCount", 1)

                    speakersList.add(
                        Speaker(
                            id = id,
                            defaultName = defaultName,
                            customName = customName,
                            gender = gender,
                            genderConfidence = genderConf,
                            totalSpeakingTimeMs = speakingTime,
                            sentenceCount = sentenceCount,
                            voiceTrackId = sObj.optString("voiceTrackId", "Track ${i + 1}"),
                            selectedVoice = if (gender == SpeakerGender.FEMALE) VoiceType.FEMALE_VOICE else VoiceType.MALE_VOICE,
                            pitch = if (gender == SpeakerGender.FEMALE) 1.15f else 0.95f,
                            speed = 1.0f,
                            voicePreservationEnabled = true
                        )
                    )
                }

                // 2. Parse Segments
                val segmentsList = mutableListOf<DialogueSegment>()
                val segArray = json.optJSONArray("segments") ?: JSONArray()
                for (i in 0 until segArray.length()) {
                    val segObj = segArray.getJSONObject(i)
                    val segId = segObj.optString("id", "seg_${i + 1}")
                    val speakerId = segObj.optString("speakerId", "spk_1")
                    val startMs = segObj.optLong("start_ms", 0L)
                    val endMs = segObj.optLong("end_ms", 0L)
                    val origText = segObj.optString("originalText", segObj.optString("text", ""))
                    val transText = segObj.optString("translatedText", "")
                    val origLang = segObj.optString("originalLanguage", "bn")
                    val targetLang = segObj.optString("targetLanguage", "en")

                    segmentsList.add(
                        DialogueSegment(
                            id = segId,
                            speakerId = speakerId,
                            startMs = startMs,
                            endMs = endMs,
                            originalText = origText,
                            translatedText = transText,
                            originalLanguage = origLang,
                            targetLanguage = targetLang
                        )
                    )
                }

                return@withContext Pair(speakersList, segmentsList)
            }
        } catch (e: IOException) {
            throw LocalServerOfflineException(cleanUrl, e)
        }
    }

    override suspend fun downloadExportFile(
        serverUrl: String,
        jobId: String,
        format: String
    ): ByteArray = withContext(Dispatchers.IO) {
        val cleanUrl = serverUrl.trimEnd('/')
        val request = Request.Builder()
            .url("$cleanUrl/api/jobs/$jobId/download/$format")
            .get()
            .build()

        try {
            transferHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("সার্ভার থেকে আউটপুট ফাইল ডাউনলোড করা যায়নি (HTTP ${response.code})")
                }
                return@withContext response.body?.bytes()
                    ?: throw IOException("সার্ভার থেকে শূন্য ডেটা ফেরত এসেছে")
            }
        } catch (e: IOException) {
            throw LocalServerOfflineException(cleanUrl, e)
        }
    }
}
