package com.example.export

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.model.DialogueSegment
import com.example.model.Speaker
import com.example.model.SubtitleLanguageOption
import java.io.File

object SubtitleExportHelper {

    fun generateSrt(
        segments: List<DialogueSegment>,
        speakers: List<Speaker>,
        languageOption: SubtitleLanguageOption,
        showSpeakerName: Boolean
    ): String {
        val speakerMap = speakers.associate { it.id to it.displayName }
        val sb = StringBuilder()

        segments.forEachIndexed { index, seg ->
            val speakerName = speakerMap[seg.speakerId] ?: seg.speakerId
            sb.append("${index + 1}\n")
            sb.append("${formatSrtTime(seg.startMs)} --> ${formatSrtTime(seg.endMs)}\n")

            val prefix = if (showSpeakerName) "$speakerName: " else ""
            when (languageOption) {
                SubtitleLanguageOption.ORIGINAL_LANGUAGE -> {
                    sb.append("$prefix${seg.originalText}\n\n")
                }
                SubtitleLanguageOption.TARGET_LANGUAGE -> {
                    val text = seg.translatedText.ifBlank { seg.originalText }
                    sb.append("$prefix$text\n\n")
                }
                SubtitleLanguageOption.BOTH -> {
                    sb.append("$prefix${seg.originalText}\n")
                    if (seg.translatedText.isNotBlank()) {
                        sb.append("${seg.translatedText}\n")
                    }
                    sb.append("\n")
                }
            }
        }
        return sb.toString()
    }

    fun generateVtt(
        segments: List<DialogueSegment>,
        speakers: List<Speaker>,
        languageOption: SubtitleLanguageOption,
        showSpeakerName: Boolean
    ): String {
        val speakerMap = speakers.associate { it.id to it.displayName }
        val sb = StringBuilder()
        sb.append("WEBVTT - AI Video Translator\n\n")

        segments.forEachIndexed { index, seg ->
            val speakerName = speakerMap[seg.speakerId] ?: seg.speakerId
            sb.append("${index + 1}\n")
            sb.append("${formatVttTime(seg.startMs)} --> ${formatVttTime(seg.endMs)}\n")

            val prefix = if (showSpeakerName) "<v $speakerName>" else ""
            val suffix = if (showSpeakerName) "</v>" else ""

            when (languageOption) {
                SubtitleLanguageOption.ORIGINAL_LANGUAGE -> {
                    sb.append("$prefix${seg.originalText}$suffix\n\n")
                }
                SubtitleLanguageOption.TARGET_LANGUAGE -> {
                    val text = seg.translatedText.ifBlank { seg.originalText }
                    sb.append("$prefix$text$suffix\n\n")
                }
                SubtitleLanguageOption.BOTH -> {
                    sb.append("$prefix${seg.originalText}\n")
                    sb.append("${seg.translatedText}$suffix\n\n")
                }
            }
        }
        return sb.toString()
    }

    fun generateTranscriptTxt(
        segments: List<DialogueSegment>,
        speakers: List<Speaker>
    ): String {
        val speakerMap = speakers.associate { it.id to "${it.displayName} (${it.gender.labelEnglish})" }
        val sb = StringBuilder()
        sb.append("=========================================\n")
        sb.append("AI Video Translator - Full Transcript\n")
        sb.append("=========================================\n\n")

        segments.forEach { seg ->
            val speaker = speakerMap[seg.speakerId] ?: seg.speakerId
            val time = seg.formattedStartTime()
            sb.append("[$time] $speaker:\n")
            sb.append("  Original: \"${seg.originalText}\"\n")
            if (seg.translatedText.isNotBlank()) {
                sb.append("  Translated: \"${seg.translatedText}\"\n")
            }
            sb.append("\n")
        }
        return sb.toString()
    }

    fun shareExportFile(context: Context, content: String, fileName: String, mimeType: String = "text/plain") {
        try {
            val cacheDir = File(context.cacheDir, "exports")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val file = File(cacheDir, fileName)
            file.writeText(content)

            val uri: Uri = try {
                FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            } catch (e: Exception) {
                Uri.fromFile(file)
            }

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, fileName)
                putExtra(Intent.EXTRA_TEXT, content)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Export $fileName"))
        } catch (e: Exception) {
            // Fallback to text intent
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, fileName)
                putExtra(Intent.EXTRA_TEXT, content)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Export $fileName"))
        }
    }

    fun shareExportBinaryFile(context: Context, bytes: ByteArray, fileName: String, mimeType: String) {
        val cacheDir = File(context.cacheDir, "exports")
        if (!cacheDir.exists()) cacheDir.mkdirs()
        val file = File(cacheDir, fileName)
        file.writeBytes(bytes)

        val uri: Uri = try {
            FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        } catch (e: Exception) {
            Uri.fromFile(file)
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, fileName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Save or Share $fileName"))
    }

    private fun formatSrtTime(ms: Long): String {
        val hours = ms / 3600000
        val minutes = (ms % 3600000) / 60000
        val seconds = (ms % 60000) / 1000
        val millis = ms % 1000
        return String.format("%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    private fun formatVttTime(ms: Long): String {
        val hours = ms / 3600000
        val minutes = (ms % 3600000) / 60000
        val seconds = (ms % 60000) / 1000
        val millis = ms % 1000
        return String.format("%02d:%02d:%02d.%03d", hours, minutes, seconds, millis)
    }
}
