package com.example

import androidx.compose.material3.Text
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.model.ProcessingStep
import com.example.model.ProgressStepState
import com.example.model.StepStatus
import com.example.ui.components.ProcessingProgressView
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    val sampleSteps = listOf(
      ProgressStepState(ProcessingStep.UPLOADING, StepStatus.COMPLETED, 100),
      ProgressStepState(ProcessingStep.EXTRACTING_AUDIO, StepStatus.COMPLETED, 100),
      ProgressStepState(ProcessingStep.DETECTING_SPEAKERS, StepStatus.COMPLETED, 100),
      ProgressStepState(ProcessingStep.TRANSCRIBING, StepStatus.COMPLETED, 100),
      ProgressStepState(ProcessingStep.TRANSLATING, StepStatus.IN_PROGRESS, 65),
      ProgressStepState(ProcessingStep.GENERATING_VOICE, StepStatus.PENDING, 0),
      ProgressStepState(ProcessingStep.RENDERING_VIDEO, StepStatus.PENDING, 0),
    )

    composeTestRule.setContent {
      MyApplicationTheme {
        ProcessingProgressView(
          steps = sampleSteps,
          isProcessing = true,
          errorMessage = null,
          onRetry = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}

