"""
Local AI Video Translator - Production Backend Server.
Zero External APIs | Zero Paid APIs | Zero API Keys Required.
Runs 100% locally with open-source models (Whisper, PyAnnote, MarianMT/NLLB-200, Piper TTS, FFmpeg).
"""

import os
import time
import uuid
import threading
import queue
import sqlite3
import json
import psutil
from typing import Dict, Any, List

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from engine.video_engine import LocalVideoEngine
from engine.stt_engine import LocalSTTEngine
from engine.diarization_engine import LocalDiarizationEngine
from engine.translation_engine import LocalTranslationEngine
from engine.tts_engine import LocalTTSEngine

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STORAGE_DIR = os.path.join(BASE_DIR, "storage")
MODELS_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(STORAGE_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)

app = FastAPI(
    title="AI Video Translator - Local AI Backend",
    description="Local, offline video translation backend. No cloud APIs, no API keys.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Hardware Detection
try:
    import torch
    CUDA_AVAILABLE = torch.cuda.is_available()
    GPU_NAME = torch.cuda.get_device_name(0) if CUDA_AVAILABLE else "None (CPU Mode)"
    DEVICE_TYPE = "cuda" if CUDA_AVAILABLE else "cpu"
except ImportError:
    CUDA_AVAILABLE = False
    GPU_NAME = "CPU Mode"
    DEVICE_TYPE = "cpu"

CPU_CORES = psutil.cpu_count(logical=True)
TOTAL_RAM_GB = round(psutil.virtual_memory().total / (1024 ** 3), 1)

# Initialize Local Processing Engines
video_engine = LocalVideoEngine()
stt_engine = LocalSTTEngine(models_dir=os.path.join(MODELS_DIR, "stt"))
diarization_engine = LocalDiarizationEngine()
translation_engine = LocalTranslationEngine(models_dir=os.path.join(MODELS_DIR, "translation"))
tts_engine = LocalTTSEngine(models_dir=os.path.join(MODELS_DIR, "tts"))

# Background Job Queue System
job_queue: queue.Queue = queue.Queue()
jobs_db: Dict[str, Dict[str, Any]] = {}
DB_PATH = os.path.join(STORAGE_DIR, "fluentvideo_jobs.sqlite3")

def init_db():
    os.makedirs(STORAGE_DIR, exist_ok=True)
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id TEXT PRIMARY KEY,
                    status TEXT,
                    current_step TEXT,
                    progress_percent INTEGER,
                    status_message TEXT,
                    error_message TEXT,
                    data_json TEXT,
                    created_at REAL
                )
            """)
            conn.commit()
    except Exception as e:
        print(f"[DB] Init error: {e}")

def persist_job(job: dict):
    """Persists job status to local SQLite database so 20-min jobs survive restarts."""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                INSERT INTO jobs (job_id, status, current_step, progress_percent, status_message, error_message, data_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(job_id) DO UPDATE SET
                    status=excluded.status,
                    current_step=excluded.current_step,
                    progress_percent=excluded.progress_percent,
                    status_message=excluded.status_message,
                    error_message=excluded.error_message,
                    data_json=excluded.data_json
            """, (
                job["job_id"],
                job.get("status", "QUEUED"),
                job.get("current_step", "QUEUED"),
                job.get("progress_percent", 0),
                job.get("status_message", ""),
                job.get("error_message"),
                json.dumps(job),
                job.get("created_at", time.time())
            ))
            conn.commit()
    except Exception as e:
        print(f"[DB] Error persisting job {job.get('job_id')}: {e}")

def load_persisted_jobs():
    """Restores previously tracked jobs from local SQLite."""
    try:
        init_db()
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT job_id, data_json FROM jobs")
            rows = cursor.fetchall()
            for jid, djson in rows:
                try:
                    jobs_db[jid] = json.loads(djson)
                except Exception:
                    pass
        print(f"[DB] Loaded {len(jobs_db)} persisted jobs from SQLite.")
    except Exception as e:
        print(f"[DB] Load error: {e}")

load_persisted_jobs()

def get_hardware_status() -> Dict[str, Any]:
    available_ram = round(psutil.virtual_memory().available / (1024 ** 3), 1)
    return {
        "status": "online",
        "mode": "100% Local & Offline",
        "no_api_key_needed": True,
        "gpu_available": CUDA_AVAILABLE,
        "gpu_name": GPU_NAME,
        "execution_device": DEVICE_TYPE,
        "cpu_cores": CPU_CORES,
        "total_ram_gb": TOTAL_RAM_GB,
        "available_ram_gb": available_ram,
        "models": {
            "stt": "Faster-Whisper (Local)",
            "diarization": "Acoustic Diarization & Voice Timbre (Local)",
            "translation": "MarianMT / NLLB-200 Bangla<->English (Local)",
            "tts": "Piper Neural Voice Synthesis (Local)",
            "ffmpeg": "Local FFmpeg / FFprobe" if video_engine.check_ffmpeg() else "Simulated Rendering"
        },
        "estimated_speed": "1.8x real-time (CUDA)" if CUDA_AVAILABLE else "0.8x real-time (CPU)",
        "queue_depth": job_queue.qsize()
    }

def process_job_worker():
    """Background worker thread processing jobs with granular sub-progress and timeline sync."""
    while True:
        try:
            job_id = job_queue.get()
            if job_id is None:
                break

            job = jobs_db.get(job_id)
            if not job:
                job_queue.task_done()
                continue

            job["status"] = "PROCESSING"
            persist_job(job)

            video_path = job["input_video_path"]
            source_lang = job["source_lang"]
            target_lang = job["target_lang"]

            job_dir = os.path.join(STORAGE_DIR, job_id)
            os.makedirs(job_dir, exist_ok=True)

            # Step 1: Local Video Processing
            job["current_step"] = "LOCAL_VIDEO_PROCESSING"
            job["progress_percent"] = 10
            job["status_message"] = "Analyzing video stream and codecs with local FFprobe..."
            persist_job(job)
            meta = video_engine.probe_video(video_path)
            job["metadata"] = meta

            # Step 2: Local Audio Extraction
            job["current_step"] = "LOCAL_AUDIO_EXTRACTION"
            job["progress_percent"] = 25
            job["status_message"] = "Extracting 16kHz mono audio track using local FFmpeg..."
            persist_job(job)
            wav_path = os.path.join(job_dir, "extracted_audio.wav")
            video_engine.extract_audio_wav(video_path, wav_path)

            # Step 3: Local Speech-to-Text
            job["current_step"] = "LOCAL_SPEECH_TO_TEXT"
            job["progress_percent"] = 40
            job["status_message"] = "Transcribing audio locally with Faster-Whisper..."
            persist_job(job)
            stt_segments = stt_engine.transcribe(wav_path, language=source_lang)
            if not stt_segments:
                raise RuntimeError("ভিডিওর অডিও ট্র্যাক থেকে কোনো কথা শনাক্ত করা যায়নি (No speech detected in audio track). অনুগ্রহ করে স্পষ্ট অডিও/কথাযুক্ত ভিডিও ব্যবহার করুন।")

            job["status_message"] = f"Transcribed {len(stt_segments)} speech turns with Faster-Whisper."
            persist_job(job)

            # Step 4: Local Speaker Diarization (Multi-speaker 3+ supported)
            job["current_step"] = "LOCAL_SPEAKER_DIARIZATION"
            job["progress_percent"] = 55
            job["status_message"] = "Analyzing acoustic vocal timbre and grouping speakers..."
            persist_job(job)
            speakers, assigned_segments = diarization_engine.diarize_segments(stt_segments, wav_path)
            job["speakers"] = speakers
            job["status_message"] = f"Identified {len(speakers)} distinct speakers across {len(assigned_segments)} dialogue segments."
            persist_job(job)

            # Step 5: Local Translation with Granular Progress
            job["current_step"] = "LOCAL_TRANSLATION"
            job["progress_percent"] = 65
            total_segs = len(assigned_segments)
            for idx, seg in enumerate(assigned_segments):
                translated = translation_engine.translate(seg["text"], source_lang, target_lang)
                seg["originalText"] = seg["text"]
                seg["translatedText"] = translated
                seg["originalLanguage"] = source_lang
                seg["targetLanguage"] = target_lang

                pct = 65 + int(((idx + 1) / max(1, total_segs)) * 12)
                job["progress_percent"] = pct
                job["status_message"] = f"Translating dialogue {idx+1}/{total_segs} ({source_lang} -> {target_lang})..."
                persist_job(job)

            job["segments"] = assigned_segments

            # Step 6: Local Text-to-Speech & Timeline Synchronization
            # Fix #1 & #2: Synthesize per-segment with speaker voice settings & assemble master timeline WAV
            job["current_step"] = "LOCAL_TEXT_TO_SPEECH"
            job["progress_percent"] = 78
            job["status_message"] = "Dubbing dialogues and assembling audio timeline (per-segment alignment)..."
            persist_job(job)

            tts_audio_path = os.path.join(job_dir, "translated_speech.wav")
            video_duration_sec = meta.get("duration_sec", 0.0)

            def update_tts_progress(curr, total, msg):
                pct = 78 + int((curr / max(1, total)) * 14)
                job["progress_percent"] = min(92, pct)
                job["status_message"] = msg
                persist_job(job)

            tts_engine.assemble_timeline_dubbed_audio(
                segments=assigned_segments,
                speakers=speakers,
                output_wav_path=tts_audio_path,
                video_duration_sec=video_duration_sec,
                lang=target_lang,
                temp_dir=os.path.join(job_dir, "tts_temp"),
                progress_callback=update_tts_progress
            )

            # Step 7: Local Subtitle Generation & Video Rendering
            job["current_step"] = "LOCAL_VIDEO_RENDERING"
            job["progress_percent"] = 94
            job["status_message"] = "Generating SRT/VTT and rendering final video with local FFmpeg..."
            persist_job(job)

            srt_path = os.path.join(job_dir, "subtitles.srt")
            write_srt_file(srt_path, assigned_segments)

            output_mp4_path = os.path.join(job_dir, "translated_video_output.mp4")
            video_engine.render_final_video(video_path, tts_audio_path, srt_path, output_mp4_path, burn_subtitles=True)

            job["output_files"] = {
                "mp4": output_mp4_path,
                "audio": tts_audio_path,
                "srt": srt_path
            }

            job["status"] = "COMPLETED"
            job["progress_percent"] = 100
            job["status_message"] = "Local video translation and timeline synchronization completed successfully!"
            persist_job(job)
            job_queue.task_done()
        except Exception as e:
            print(f"[Worker] Job processing failed: {e}")
            if job:
                job["status"] = "FAILED"
                job["error_message"] = str(e)
                job["status_message"] = f"Failed: {e}"
                persist_job(job)
            job_queue.task_done()

def write_srt_file(file_path: str, segments: list):
    """Generates standard SRT subtitles file."""
    def ms_to_srt_time(ms: int) -> str:
        s, ms_rem = divmod(ms, 1000)
        m, s = divmod(s, 60)
        h, m = divmod(m, 60)
        return f"{h:02d}:{m:02d}:{s:02d},{ms_rem:03d}"

    with open(file_path, "w", encoding="utf-8") as f:
        for idx, seg in enumerate(segments, 1):
            start = ms_to_srt_time(seg.get("start_ms", 0))
            end = ms_to_srt_time(seg.get("end_ms", 0))
            text = seg.get("translatedText", seg.get("text", ""))
            f.write(f"{idx}\n{start} --> {end}\n{text}\n\n")

# Start background queue thread
worker_thread = threading.Thread(target=process_job_worker, daemon=True)
worker_thread.start()

# API Endpoints
@app.get("/")
@app.get("/health")
@app.get("/api/system/status")
def system_status():
    return get_hardware_status()

@app.post("/api/jobs/create")
async def create_job(
    video: UploadFile = File(...),
    source_lang: str = Form("bn"),
    target_lang: str = Form("en")
):
    job_id = str(uuid.uuid4())[:8]
    job_dir = os.path.join(STORAGE_DIR, job_id)
    os.makedirs(job_dir, exist_ok=True)

    input_video_path = os.path.join(job_dir, video.filename or "input.mp4")
    # Streaming write to disk in 1MB chunks to protect server RAM for large 20-min video files
    with open(input_video_path, "wb") as f:
        while True:
            chunk = await video.read(1024 * 1024)
            if not chunk:
                break
            f.write(chunk)

    job_data = {
        "job_id": job_id,
        "filename": video.filename,
        "input_video_path": input_video_path,
        "source_lang": source_lang,
        "target_lang": target_lang,
        "status": "QUEUED",
        "current_step": "QUEUED",
        "progress_percent": 0,
        "status_message": "Job enqueued in local background queue...",
        "created_at": time.time(),
        "speakers": [],
        "segments": [],
        "error_message": None
    }
    jobs_db[job_id] = job_data
    persist_job(job_data)
    job_queue.put(job_id)

    return {
        "job_id": job_id,
        "status": "QUEUED",
        "message": "Video successfully uploaded to local queue. No external APIs used."
    }

@app.get("/api/jobs/{job_id}/status")
def get_job_status(job_id: str):
    job = jobs_db.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return {
        "job_id": job_id,
        "status": job["status"],
        "current_step": job["current_step"],
        "progress_percent": job["progress_percent"],
        "status_message": job.get("status_message", ""),
        "error_message": job.get("error_message")
    }

@app.get("/api/jobs/{job_id}/result")
def get_job_result(job_id: str):
    job = jobs_db.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    if job["status"] != "COMPLETED":
        return {"status": job["status"], "progress_percent": job["progress_percent"]}
    return {
        "job_id": job_id,
        "status": "COMPLETED",
        "speakers": job.get("speakers", []),
        "segments": job.get("segments", []),
        "metadata": job.get("metadata", {})
    }

@app.get("/api/jobs/{job_id}/download/{format}")
def download_export(job_id: str, format: str):
    job = jobs_db.get(job_id)
    if not job or job["status"] != "COMPLETED":
        raise HTTPException(status_code=404, detail="Output file not ready")

    output_files = job.get("output_files", {})
    if format == "mp4" and "mp4" in output_files:
        return FileResponse(output_files["mp4"], media_type="video/mp4", filename=f"translated_{job_id}.mp4")
    elif format in ["srt", "vtt"] and "srt" in output_files:
        return FileResponse(output_files["srt"], media_type="text/plain", filename=f"subtitles_{job_id}.srt")
    elif format in ["audio", "wav"] and "audio" in output_files:
        return FileResponse(output_files["audio"], media_type="audio/wav", filename=f"audio_{job_id}.wav")

    raise HTTPException(status_code=400, detail="Requested format not available")

if __name__ == "__main__":
    import uvicorn
    print("=" * 65)
    print("STARTING LOCAL AI VIDEO TRANSLATOR BACKEND")
    print(f"Device: {GPU_NAME} | RAM: {TOTAL_RAM_GB} GB | CPU: {CPU_CORES} cores")
    print("100% OFFLINE LOCAL EXECUTION - ZERO API KEYS NEEDED")
    print("=" * 65)
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
