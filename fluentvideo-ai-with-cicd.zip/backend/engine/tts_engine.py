"""
Local Text-to-Speech (TTS) Engine.
Generates neural translated speech for each speaker using local Piper TTS or espeak-ng.
Zero Sine-Wave Beeps. Zero Cloud APIs. Zero Paid Endpoints.
"""

import os
import subprocess
import shutil
from typing import Optional

# Universal language mapping for espeak-ng voice codes (100+ languages supported offline)
ESPEAK_VOICE_MAP = {
    "en": "en-us",
    "bn": "bn",
    "hi": "hi",
    "es": "es",
    "fr": "fr",
    "de": "de",
    "ar": "ar",
    "zh": "cmn",
    "ja": "ja",
    "ru": "ru",
    "ur": "ur",
    "pt": "pt-br",
    "it": "it",
    "tr": "tr",
    "ko": "ko",
    "ta": "ta",
    "te": "te",
    "mr": "mr",
    "gu": "gu",
    "pa": "pa",
    "fa": "fa",
    "id": "id",
    "vi": "vi",
    "nl": "nl",
    "pl": "pl",
    "sv": "sv",
    "th": "th",
    "el": "el",
    "cs": "cs",
    "ro": "ro",
    "hu": "hu",
    "uk": "uk"
}

class LocalTTSEngine:
    def __init__(self, models_dir: Optional[str] = None):
        self.models_dir = models_dir or os.path.join(os.path.dirname(__file__), "..", "models", "tts")
        os.makedirs(self.models_dir, exist_ok=True)
        self.has_piper = self._check_piper_available()
        self.has_espeak = self._check_espeak_available()

    def _check_piper_available(self) -> bool:
        """Checks if piper CLI or python package is available."""
        if shutil.which("piper") is not None:
            return True
        try:
            import piper
            return True
        except ImportError:
            return False

    def _check_espeak_available(self) -> bool:
        """Checks if espeak-ng CLI is available."""
        return shutil.which("espeak-ng") is not None or shutil.which("espeak") is not None

    def synthesize_segment(
        self,
        text: str,
        output_wav_path: str,
        lang: str = "en",
        pitch_mod: float = 1.0,
        speed_mod: float = 1.0
    ) -> bool:
        """
        Synthesizes speech using local neural TTS.
        Never generates beep tones or mock audio.
        """
        clean_text = text.strip()
        if not clean_text:
            return False

        # 1. Try local Piper neural synthesis
        # Look for downloaded Piper ONNX model
        piper_voice_found = False
        voice_onnx = None

        possible_models = [
            os.path.join(self.models_dir, f"{lang}_voice.onnx"),
            os.path.join(self.models_dir, f"{lang}.onnx"),
            os.path.join(self.models_dir, "en_US-lessac-medium.onnx" if lang == "en" else "bn_BD-fahim-medium.onnx")
        ]

        # Also search for any onnx file starting with language prefix
        if os.path.exists(self.models_dir):
            for fname in os.listdir(self.models_dir):
                if fname.endswith(".onnx") and (fname.startswith(f"{lang}_") or fname.startswith(f"{lang}-")):
                    possible_models.append(os.path.join(self.models_dir, fname))

        for p in possible_models:
            if os.path.exists(p):
                voice_onnx = p
                piper_voice_found = True
                break

        if self.has_piper and piper_voice_found and voice_onnx:
            try:
                print(f"[LocalTTS] Synthesizing speech with Piper ({voice_onnx})...")
                piper_bin = shutil.which("piper") or "piper"
                cmd = [
                    piper_bin,
                    "--model", voice_onnx,
                    "--output_file", output_wav_path
                ]
                if speed_mod != 1.0:
                    cmd.extend(["--length-scale", str(round(1.0 / max(0.5, speed_mod), 2))])

                proc = subprocess.Popen(
                    cmd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                stdout, stderr = proc.communicate(input=clean_text)
                if proc.returncode == 0 and os.path.exists(output_wav_path) and os.path.getsize(output_wav_path) > 0:
                    print(f"[LocalTTS] ✓ Piper speech synthesized: {output_wav_path}")
                    return True
                else:
                    print(f"[LocalTTS] Piper execution error: {stderr}")
            except Exception as e:
                print(f"[LocalTTS] Piper error: {e}")

        # 2. Try espeak-ng as an offline local neural phonetic synthesizer
        if self.has_espeak:
            try:
                espeak_bin = shutil.which("espeak-ng") or shutil.which("espeak")
                clean_lang = lang.lower().split("_")[0].split("-")[0]
                voice = ESPEAK_VOICE_MAP.get(clean_lang, clean_lang)
                speed_wpm = int(175 * max(0.5, min(2.0, speed_mod)))
                pitch_val = int(50 * max(0.5, min(2.0, pitch_mod)))

                print(f"[LocalTTS] Synthesizing speech with {espeak_bin} (Voice: {voice} for lang: {lang})...")
                cmd = [
                    espeak_bin,
                    f"-v{voice}",
                    f"-s{speed_wpm}",
                    f"-p{pitch_val}",
                    "-w", output_wav_path,
                    clean_text
                ]
                res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if res.returncode == 0 and os.path.exists(output_wav_path) and os.path.getsize(output_wav_path) > 0:
                    print(f"[LocalTTS] ✓ espeak-ng speech synthesized: {output_wav_path}")
                    return True
                else:
                    print(f"[LocalTTS] espeak-ng failed: {res.stderr.decode('utf-8', errors='ignore')}")
            except Exception as e:
                print(f"[LocalTTS] espeak-ng exception: {e}")

        # If neither is available, fail honestly. DO NOT GENERATE SINE WAVE BEEPS!
        err_msg = (
            "স্থানীয় টিটিএস ইঞ্জিন পাওয়া যায়নি (No local TTS engine available). "
            "অনুগ্রহ করে সিস্টেমে 'piper' অথবা 'espeak-ng' ইনস্টল করুন এবং "
            "'python download_models.py' চালিয়ে ভয়েস মডেল ডাউনলোড করুন। "
            "কোনো ক্লাউড এপিআই বা বিপ-টোন ব্যবহার করা হবে না।"
        )
        print(f"[LocalTTS] ❌ {err_msg}")
        raise RuntimeError(err_msg)

    def assemble_timeline_dubbed_audio(
        self,
        segments: list,
        speakers: list,
        output_wav_path: str,
        video_duration_sec: float,
        lang: str = "bn",
        temp_dir: str = None,
        progress_callback = None
    ) -> bool:
        """
        Synthesizes speech per dialogue segment using speaker-specific voice pitch/speed,
        and places each segment at its exact start_ms timeline offset into a master audio track.
        Guarantees 100% timeline synchronization for videos up to 20+ minutes.
        """
        import array

        if not temp_dir:
            temp_dir = os.path.dirname(output_wav_path)
        os.makedirs(temp_dir, exist_ok=True)

        # Build speaker voice profiles
        speaker_profiles = {}
        male_idx = 0
        female_idx = 0
        male_pitches = [0.88, 0.96, 0.80, 0.92, 0.84]
        female_pitches = [1.22, 1.32, 1.15, 1.28, 1.38]

        for spk in speakers:
            spk_id = spk.get("id", "spk_1")
            gender = spk.get("gender", "UNKNOWN_NOT_CONFIDENT")
            if gender == "FEMALE":
                pitch = female_pitches[female_idx % len(female_pitches)]
                female_idx += 1
            elif gender == "MALE":
                pitch = male_pitches[male_idx % len(male_pitches)]
                male_idx += 1
            else:
                pitch = 1.05 if (male_idx + female_idx) % 2 == 0 else 0.95

            speaker_profiles[spk_id] = {
                "pitch_mod": pitch,
                "speed_mod": 1.0,
                "name": spk.get("customName") or spk.get("defaultName") or spk_id
            }

        # Target 16kHz mono audio timeline
        sample_rate = 16000
        total_samples = int(max(video_duration_sec, 1.0) * sample_rate)
        master_buffer = array.array('h', [0] * total_samples)

        total_segs = len(segments)
        for idx, seg in enumerate(segments):
            text = (seg.get("translatedText") or seg.get("text", "")).strip()
            if not text:
                continue

            spk_id = seg.get("speakerId", "spk_1")
            profile = speaker_profiles.get(spk_id, {"pitch_mod": 1.0, "speed_mod": 1.0, "name": "Speaker"})

            if progress_callback:
                progress_callback(idx + 1, total_segs, f"Dubbing dialogue {idx+1}/{total_segs} ({profile['name']})...")

            start_ms = seg.get("start_ms", 0)
            start_sample = int((start_ms / 1000.0) * sample_rate)

            seg_raw_wav = os.path.join(temp_dir, f"seg_{idx}_raw.wav")
            seg_std_wav = os.path.join(temp_dir, f"seg_{idx}_16k.wav")

            try:
                # 1. Synthesize this segment
                self.synthesize_segment(
                    text=text,
                    output_wav_path=seg_raw_wav,
                    lang=lang,
                    pitch_mod=profile["pitch_mod"],
                    speed_mod=profile["speed_mod"]
                )

                # 2. Normalize to 16kHz mono 16-bit PCM using local FFmpeg
                res = subprocess.run([
                    "ffmpeg", "-y", "-i", seg_raw_wav,
                    "-ar", str(sample_rate), "-ac", "1", "-c:a", "pcm_s16le",
                    seg_std_wav
                ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

                if res.returncode == 0 and os.path.exists(seg_std_wav):
                    with wave.open(seg_std_wav, "rb") as wf:
                        num_frames = wf.getnframes()
                        raw_bytes = wf.readframes(num_frames)
                        seg_samples = array.array('h')
                        seg_samples.frombytes(raw_bytes)

                    # Expand buffer if segment extends beyond current buffer
                    needed_size = start_sample + len(seg_samples)
                    if needed_size > len(master_buffer):
                        master_buffer.extend([0] * (needed_size - len(master_buffer)))

                    # Mix segment samples into timeline buffer
                    for i in range(len(seg_samples)):
                        pos = start_sample + i
                        mixed = master_buffer[pos] + seg_samples[i]
                        if mixed > 32767:
                            mixed = 32767
                        elif mixed < -32768:
                            mixed = -32768
                        master_buffer[pos] = mixed
            except Exception as e:
                print(f"[LocalTTS] Error dubbing segment {idx}: {e}")
            finally:
                # Clean up intermediate wav files
                for p in [seg_raw_wav, seg_std_wav]:
                    if os.path.exists(p):
                        try:
                            os.remove(p)
                        except Exception:
                            pass

        # Pad with silence up to exact video duration if needed
        min_samples = int(video_duration_sec * sample_rate)
        if len(master_buffer) < min_samples:
            master_buffer.extend([0] * (min_samples - len(master_buffer)))

        # Write master timeline WAV
        with wave.open(output_wav_path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(master_buffer.tobytes())

        print(f"[LocalTTS] ✓ Master audio timeline assembled ({len(master_buffer) / sample_rate:.2f}s): {output_wav_path}")
        return True

