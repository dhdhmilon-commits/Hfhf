package com.example.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.ExportFormat
import com.example.model.SupportedLanguage
import com.example.model.VideoItem
import com.example.ui.components.LocalServerHubDialog
import com.example.ui.components.ProcessingProgressView
import com.example.ui.components.SpeakerListView
import com.example.ui.components.SubtitleAndExportView
import com.example.ui.components.TranscriptView
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimary
import com.example.viewmodel.VideoTranslatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoTranslatorScreen(
    viewModel: VideoTranslatorViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val snackbarHostState = remember { SnackbarHostState() }

    val videoItem by viewModel.videoItem.collectAsStateWithLifecycle()
    val sourceLanguage by viewModel.sourceLanguage.collectAsStateWithLifecycle()
    val targetLanguage by viewModel.targetLanguage.collectAsStateWithLifecycle()
    val pipelineSteps by viewModel.pipelineSteps.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val speakers by viewModel.speakers.collectAsStateWithLifecycle()
    val dialogues by viewModel.dialogues.collectAsStateWithLifecycle()

    val localServerInfo by viewModel.localServerInfo.collectAsStateWithLifecycle()
    val jobQueueStatus by viewModel.jobQueueStatus.collectAsStateWithLifecycle()
    val showServerHubDialog by viewModel.showServerHubDialog.collectAsStateWithLifecycle()

    val showOriginalSubtitle by viewModel.showOriginalSubtitle.collectAsStateWithLifecycle()
    val showTranslatedSubtitle by viewModel.showTranslatedSubtitle.collectAsStateWithLifecycle()
    val showSpeakerName by viewModel.showSpeakerName.collectAsStateWithLifecycle()
    val showTimestamp by viewModel.showTimestamp.collectAsStateWithLifecycle()
    val subtitleLanguageOption by viewModel.subtitleLanguageOption.collectAsStateWithLifecycle()

    val voiceConsent by viewModel.voicePreservationConsentGranted.collectAsStateWithLifecycle()
    val previewTab by viewModel.previewTab.collectAsStateWithLifecycle()

    val selectedExportFormat by viewModel.selectedExportFormat.collectAsStateWithLifecycle()
    val selectedQuality by viewModel.selectedQuality.collectAsStateWithLifecycle()
    val selectedAudioOption by viewModel.selectedAudioOption.collectAsStateWithLifecycle()
    val exportSuccessMessage by viewModel.exportSuccessMessage.collectAsStateWithLifecycle()

    // File Picker for user uploaded videos
    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.selectVideoUri(context, uri)
        }
    }

    LaunchedEffect(exportSuccessMessage) {
        exportSuccessMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.dismissExportSuccess()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AI Video Translator",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = IndigoPrimary.copy(alpha = 0.2f),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Text(
                                    text = "AI v3.5",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = CyanAccent),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Bangla ↔ English Video Translation",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.openServerHubDialog() },
                        modifier = Modifier.testTag("open_server_hub_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Dns,
                            contentDescription = "Local Engine Hub",
                            tint = CyanAccent
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Hero Banner Art
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0F172A))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_trans),
                    contentDescription = "AI Video Translation Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.85f),
                                    Color.Transparent
                                )
                            )
                        )
                        .padding(16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Column {
                        Text(
                            text = "Multimodal Speech & Video AI",
                            style = MaterialTheme.typography.labelMedium.copy(color = CyanAccent, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Speaker Diarization • Gender Detection • Voice Translation",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.9f))
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 100% Local AI & Hardware Status Banner
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, IndigoPrimary.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                    .clickable { viewModel.openServerHubDialog() }
                    .testTag("local_engine_status_banner"),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (localServerInfo.gpuAvailable) EmeraldSuccess else CyanAccent)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "100% Local AI • Zero Cloud APIs",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${localServerInfo.executionMode} • ${localServerInfo.speedFactor}",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = IndigoPrimary.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "Engine Hub",
                            style = MaterialTheme.typography.labelSmall.copy(color = CyanAccent, fontWeight = FontWeight.SemiBold),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ==========================================
            // 1. VIDEO UPLOAD BOX
            // ==========================================
            UploadSectionCard(
                videoItem = videoItem,
                onUploadClick = {
                    pickVideoLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
                onRemoveVideo = { viewModel.removeVideo() }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // ==========================================
            // 2. LANGUAGE SELECTION
            // ==========================================
            LanguageSelectionCard(
                sourceLanguage = sourceLanguage,
                targetLanguage = targetLanguage,
                onSourceChange = { viewModel.setSourceLanguage(it) },
                onTargetChange = { viewModel.setTargetLanguage(it) },
                onSwap = { viewModel.swapLanguages() }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // ==========================================
            // MAIN ACTION BUTTONS (Section 3, 6, 9)
            // ==========================================
            ActionButtonsRow(
                videoItem = videoItem,
                isProcessing = isProcessing,
                hasSpeakers = speakers.isNotEmpty(),
                hasDialogues = dialogues.isNotEmpty(),
                hasTranslations = dialogues.any { it.translatedText.isNotBlank() },
                onAnalyze = { viewModel.analyzeVideo() },
                onTranslate = { viewModel.translateVideo() },
                onGenerateVoice = { viewModel.generateTranslatedVoice() }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // ==========================================
            // PIPELINE PROGRESS DISPLAY (Real-time status)
            // ==========================================
            if (isProcessing || pipelineSteps.any { it.status != com.example.model.StepStatus.PENDING }) {
                ProcessingProgressView(
                    steps = pipelineSteps,
                    isProcessing = isProcessing,
                    errorMessage = errorMessage,
                    onRetry = {
                        if (speakers.isEmpty()) viewModel.analyzeVideo()
                        else viewModel.translateVideo()
                    }
                )
                Spacer(modifier = Modifier.height(14.dp))
            }

            // ==========================================
            // 10. VIDEO PREVIEW (Original | Translated)
            // ==========================================
            if (dialogues.isNotEmpty()) {
                VideoPlayerView(
                    videoItem = videoItem,
                    previewTab = previewTab,
                    onTabChange = { viewModel.setPreviewTab(it) },
                    dialogues = dialogues,
                    speakers = speakers,
                    showOriginalSubtitle = showOriginalSubtitle,
                    showTranslatedSubtitle = showTranslatedSubtitle,
                    showSpeakerName = showSpeakerName,
                    showTimestamp = showTimestamp,
                    subtitleLanguageOption = subtitleLanguageOption,
                    onSpeakDialogue = { seg, spk ->
                        viewModel.voiceManager.speakSegment(seg, spk)
                    }
                )
                Spacer(modifier = Modifier.height(14.dp))
            }

            // ==========================================
            // 4. SPEAKER DETECTION LIST
            // ==========================================
            AnimatedVisibility(visible = speakers.isNotEmpty()) {
                Column {
                    SpeakerListView(
                        speakers = speakers,
                        onUpdateSpeakerName = { id, name -> viewModel.updateSpeakerName(id, name) },
                        onUpdateSpeakerGender = { id, gender -> viewModel.updateSpeakerGender(id, gender) },
                        onUpdateSpeakerVoice = { id, voice -> viewModel.updateSpeakerVoiceType(id, voice) },
                        onUpdateSpeakerPitch = { id, pitch -> viewModel.updateSpeakerPitch(id, pitch) },
                        onUpdateSpeakerSpeed = { id, speed -> viewModel.updateSpeakerSpeed(id, speed) },
                        onPlayVoicePreview = { spk -> viewModel.playSpeakerVoicePreview(spk) }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }
            }

            // ==========================================
            // 5 & 7. ORIGINAL TRANSCRIPT & SPEAKER TRANSLATION
            // ==========================================
            AnimatedVisibility(visible = dialogues.isNotEmpty()) {
                Column {
                    TranscriptView(
                        dialogues = dialogues,
                        speakers = speakers,
                        onUpdateDialogue = { id, orig, trans -> viewModel.updateDialogueText(id, orig, trans) },
                        onSpeakDialogue = { seg, spk -> viewModel.voiceManager.speakSegment(seg, spk) }
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }
            }

            // ==========================================
            // 11 & 12. SUBTITLES & FINAL EXPORT
            // ==========================================
            AnimatedVisibility(visible = dialogues.isNotEmpty()) {
                SubtitleAndExportView(
                    showOriginalSubtitle = showOriginalSubtitle,
                    showTranslatedSubtitle = showTranslatedSubtitle,
                    showSpeakerName = showSpeakerName,
                    showTimestamp = showTimestamp,
                    subtitleLanguageOption = subtitleLanguageOption,
                    onToggleOriginalSubtitle = { viewModel.toggleShowOriginalSubtitle(it) },
                    onToggleTranslatedSubtitle = { viewModel.toggleShowTranslatedSubtitle(it) },
                    onToggleSpeakerName = { viewModel.toggleShowSpeakerName(it) },
                    onToggleTimestamp = { viewModel.toggleShowTimestamp(it) },
                    onSetSubtitleLanguage = { viewModel.setSubtitleLanguageOption(it) },
                    voicePreservationConsentGranted = voiceConsent,
                    onSetVoiceConsent = { viewModel.setVoiceCloningConsent(it) },
                    selectedExportFormat = selectedExportFormat,
                    selectedQuality = selectedQuality,
                    selectedAudioOption = selectedAudioOption,
                    onSetExportFormat = { viewModel.setExportFormat(it) },
                    onSetVideoQuality = { viewModel.setVideoQuality(it) },
                    onSetAudioOption = { viewModel.setExportAudioOption(it) },
                    isProcessing = isProcessing,
                    onExportClicked = { viewModel.renderAndExportVideo(context) },
                    onExportSubtitlesOnly = { format ->
                        when (format) {
                            ExportFormat.SRT_SUBTITLE -> {
                                val srt = com.example.export.SubtitleExportHelper.generateSrt(
                                    dialogues, speakers, subtitleLanguageOption, showSpeakerName
                                )
                                com.example.export.SubtitleExportHelper.shareExportFile(context, srt, "subtitles.srt")
                            }
                            ExportFormat.VTT_SUBTITLE -> {
                                val vtt = com.example.export.SubtitleExportHelper.generateVtt(
                                    dialogues, speakers, subtitleLanguageOption, showSpeakerName
                                )
                                com.example.export.SubtitleExportHelper.shareExportFile(context, vtt, "subtitles.vtt")
                            }
                            else -> {}
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }

        if (showServerHubDialog) {
            LocalServerHubDialog(
                serverInfo = localServerInfo,
                queueStatus = jobQueueStatus,
                onDismiss = { viewModel.closeServerHubDialog() },
                onTestConnection = { viewModel.updateLocalServerUrl(it) }
            )
        }
    }
}

@Composable
private fun UploadSectionCard(
    videoItem: VideoItem?,
    onUploadClick: () -> Unit,
    onRemoveVideo: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("upload_section_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Upload Video",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "MP4, MOV, AVI, MKV, WebM",
                    style = MaterialTheme.typography.labelSmall.copy(color = CyanAccent, fontSize = 10.sp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (videoItem == null) {
                // Drag & Drop / Upload Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .border(1.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                        .clickable(onClick = onUploadClick)
                        .padding(vertical = 24.dp, horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CloudUpload,
                            contentDescription = "Upload",
                            tint = CyanAccent,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Drag & Drop Video or Tap to Browse",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Supported: MP4, MOV, AVI, MKV, WebM",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onUploadClick,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("upload_video_button")
                        ) {
                            Text("Upload Video")
                        }
                    }
                }
            } else {
                // Uploaded Video Info Card with Preview details
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, CyanAccent.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Movie,
                                        contentDescription = null,
                                        tint = CyanAccent,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = videoItem.fileName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Duration: ${videoItem.durationFormatted} • Size: ${videoItem.fileSizeFormatted} • ${videoItem.format}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(
                            onClick = onRemoveVideo,
                            modifier = Modifier.testTag("remove_video_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Remove Video",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = onUploadClick,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Change Video", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguageSelectionCard(
    sourceLanguage: SupportedLanguage,
    targetLanguage: SupportedLanguage,
    onSourceChange: (SupportedLanguage) -> Unit,
    onTargetChange: (SupportedLanguage) -> Unit,
    onSwap: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("language_selection_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Language Selection",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Source Language Box
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Source Language",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LanguageDropdown(
                        selected = sourceLanguage,
                        options = SupportedLanguage.entries,
                        onSelect = onSourceChange
                    )
                }

                // Swap Button ⇄
                IconButton(
                    onClick = onSwap,
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .testTag("swap_language_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = "Swap Language",
                        tint = CyanAccent
                    )
                }

                // Translate To Box
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Translate To",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LanguageDropdown(
                        selected = targetLanguage,
                        options = SupportedLanguage.nonAutoLanguages,
                        onSelect = onTargetChange
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguageDropdown(
    selected: SupportedLanguage,
    options: List<SupportedLanguage>,
    onSelect: (SupportedLanguage) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredOptions = remember(options, searchQuery) {
        if (searchQuery.isBlank()) options
        else {
            options.filter {
                it.displayNameBangla.contains(searchQuery, ignoreCase = true) ||
                it.displayNameEnglish.contains(searchQuery, ignoreCase = true) ||
                it.code.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selected.displayNameBangla,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth(),
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp)
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = {
                expanded = false
                searchQuery = ""
            },
            modifier = Modifier.heightIn(max = 320.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search...", fontSize = 12.sp) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                textStyle = MaterialTheme.typography.bodySmall
            )

            if (filteredOptions.isEmpty()) {
                DropdownMenuItem(
                    text = { Text("No matching language", style = MaterialTheme.typography.bodySmall) },
                    onClick = {}
                )
            } else {
                filteredOptions.forEach { lang ->
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(text = lang.displayNameBangla, style = MaterialTheme.typography.bodyMedium)
                                Text(text = lang.displayNameEnglish, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        },
                        onClick = {
                            onSelect(lang)
                            expanded = false
                            searchQuery = ""
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionButtonsRow(
    videoItem: VideoItem?,
    isProcessing: Boolean,
    hasSpeakers: Boolean,
    hasDialogues: Boolean,
    hasTranslations: Boolean,
    onAnalyze: () -> Unit,
    onTranslate: () -> Unit,
    onGenerateVoice: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Analyze Video Button (Step 4 & 5)
        Button(
            onClick = onAnalyze,
            enabled = videoItem != null && !isProcessing,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("analyze_video_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = IndigoPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "🎬 Analyze Video",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 15.sp)
            )
        }

        // 2. Translate Video Button (Step 6 & 7)
        if (hasDialogues) {
            Button(
                onClick = onTranslate,
                enabled = !isProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("translate_video_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanAccent
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Translate, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "✨ Translate Video",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 15.sp)
                )
            }
        }

        // 3. Generate Translated Voice Button (Step 9)
        if (hasTranslations) {
            Button(
                onClick = onGenerateVoice,
                enabled = !isProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("generate_voice_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.tertiary
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🔊 Generate Translated Voice",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 15.sp)
                )
            }
        }
    }
}
