package com.example.model

import android.net.Uri

enum class SpeakerGender(val labelBangla: String, val labelEnglish: String) {
    MALE("পুরুষ (Male)", "Male"),
    FEMALE("মহিলা (Female)", "Female"),
    UNKNOWN_NOT_CONFIDENT("অনিশ্চিত (Unknown / Not confident)", "Unknown / Not confident")
}

enum class VoiceType(val labelBangla: String, val labelEnglish: String) {
    MALE_VOICE("পুরুষ কণ্ঠ (Male Voice)", "Male Voice"),
    FEMALE_VOICE("মহিলা কণ্ঠ (Female Voice)", "Female Voice"),
    NEUTRAL_VOICE("নিরপেক্ষ কণ্ঠ (Neutral Voice)", "Neutral Voice")
}

data class Speaker(
    val id: String,
    val defaultName: String,
    var customName: String,
    var gender: SpeakerGender,
    val genderConfidence: Float = 0.92f,
    val totalSpeakingTimeMs: Long = 0L,
    val sentenceCount: Int = 0,
    val voiceTrackId: String = "Track 1",
    var selectedVoice: VoiceType = VoiceType.MALE_VOICE,
    var pitch: Float = 1.0f,
    var speed: Float = 1.0f,
    var voicePreservationEnabled: Boolean = true
) {
    val displayName: String
        get() = customName.ifBlank { defaultName }

    val genderEstimateLabel: String
        get() = when (gender) {
            SpeakerGender.MALE -> "Likely Male — Confidence ${(genderConfidence * 100).toInt()}%"
            SpeakerGender.FEMALE -> "Likely Female — Confidence ${(genderConfidence * 100).toInt()}%"
            SpeakerGender.UNKNOWN_NOT_CONFIDENT -> "Unknown / Not confident"
        }
}

enum class JobQueueStatus(val labelEnglish: String, val labelBangla: String) {
    QUEUED("Queued", "অপেক্ষমান"),
    PROCESSING("Processing", "প্রক্রিয়াকরণ চলছে"),
    COMPLETED("Completed", "সম্পন্ন হয়েছে"),
    FAILED("Failed", "ব্যর্থ হয়েছে");

    val label: String get() = labelEnglish
}

data class LocalServerHardwareInfo(
    val isServerConnected: Boolean = false,
    val serverUrl: String = "http://10.0.2.2:8000",
    val gpuAvailable: Boolean = true,
    val gpuName: String = "NVIDIA RTX / CUDA Acceleration",
    val executionMode: String = "Local GPU Mode",
    val cpuCores: Int = 8,
    val ramAvailableGb: Float = 16.0f,
    val sttModel: String = "Faster-Whisper (Local Offline)",
    val diarizationModel: String = "PyAnnote Acoustic (Local Offline)",
    val translationModel: String = "MarianMT / NLLB-200 (Local Offline)",
    val ttsModel: String = "Piper Neural TTS (Local Offline)",
    val ffmpegStatus: String = "Local FFmpeg 6.1 (Available)",
    val currentJobStatus: JobQueueStatus = JobQueueStatus.QUEUED,
    val speedFactor: String = "1.6x real-time",
    val estimatedRemainingSeconds: Int = 12
)

data class DialogueSegment(
    val id: String,
    val speakerId: String,
    val startMs: Long,
    val endMs: Long,
    var originalText: String,
    var translatedText: String,
    val originalLanguage: String = "bn",
    val targetLanguage: String = "en"
) {
    fun formattedStartTime(): String = formatMsToTimestamp(startMs)
    fun formattedEndTime(): String = formatMsToTimestamp(endMs)

    companion object {
        fun formatMsToTimestamp(ms: Long): String {
            val totalSeconds = ms / 1000
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60
            return if (hours > 0) {
                String.format("%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }
        }
    }
}

data class VideoItem(
    val uri: Uri?,
    val fileName: String,
    val fileSizeFormatted: String,
    val durationMs: Long,
    val durationFormatted: String,
    val format: String,
    val isSample: Boolean = false,
    val sampleVideoUrl: String? = null
)

enum class ProcessingStep(val titleBangla: String, val titleEnglish: String) {
    UPLOADING("ভিডিও আপলোড হচ্ছে", "Uploading Video"),
    EXTRACTING_AUDIO("অডিও নিষ্কাশন করা হচ্ছে", "Extracting Audio"),
    DETECTING_SPEAKERS("বক্তা শনাক্ত করা হচ্ছে", "Detecting Speakers"),
    TRANSCRIBING("কথাগুলো রূপান্তর করা হচ্ছে", "Transcribing"),
    TRANSLATING("অনুবাদ করা হচ্ছে", "Translating"),
    GENERATING_VOICE("ভয়েস ট্র্যাক তৈরি হচ্ছে", "Generating Voice"),
    RENDERING_VIDEO("ভিডিও রেন্ডার হচ্ছে", "Rendering Video")
}

enum class StepStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}

data class ProgressStepState(
    val step: ProcessingStep,
    val status: StepStatus = StepStatus.PENDING,
    val progressPercent: Int = 0,
    val subStatusText: String = ""
)

enum class SupportedLanguage(
    val code: String,
    val displayNameBangla: String,
    val displayNameEnglish: String,
    val floresCode: String = ""
) {
    AUTO("auto", "স্বয়ংক্রিয় (Auto Detect)", "Auto Detect", ""),
    BANGLA("bn", "বাংলা (Bangla)", "Bangla", "ben_Beng"),
    ENGLISH("en", "ইংরেজি (English)", "English", "eng_Latn"),
    HINDI("hi", "हिन्दी (Hindi)", "Hindi", "hin_Deva"),
    SPANISH("es", "স্প্যানিশ (Spanish)", "Spanish", "spa_Latn"),
    FRENCH("fr", "ফরাসি (French)", "French", "fra_Latn"),
    GERMAN("de", "জার্মান (German)", "German", "deu_Latn"),
    ARABIC("ar", "আরবি (Arabic)", "Arabic", "arb_Arab"),
    URDU("ur", "উর্দু (Urdu)", "Urdu", "urd_Arab"),
    CHINESE("zh", "চীনা (Chinese)", "Chinese (Simplified)", "zho_Hans"),
    JAPANESE("ja", "জাপানি (Japanese)", "Japanese", "jpn_Jpan"),
    RUSSIAN("ru", "রুশ (Russian)", "Russian", "rus_Cyrl"),
    PORTUGUESE("pt", "পর্তুগিজ (Portuguese)", "Portuguese", "por_Latn"),
    ITALIAN("it", "ইতালীয় (Italian)", "Italian", "ita_Latn"),
    TURKISH("tr", "তুর্কি (Turkish)", "Turkish", "tur_Latn"),
    KOREAN("ko", "কোরীয় (Korean)", "Korean", "kor_Hang"),
    INDONESIAN("id", "ইন্দোনেশীয় (Indonesian)", "Indonesian", "ind_Latn"),
    VIETNAMESE("vi", "ভিয়েতনামি (Vietnamese)", "Vietnamese", "vie_Latn"),
    TAMIL("ta", "তামিল (Tamil)", "Tamil", "tam_Taml"),
    TELUGU("te", "তেলেগু (Telugu)", "Telugu", "tel_Telu"),
    MARATHI("mr", "মারাঠি (Marathi)", "Marathi", "mar_Deva"),
    GUJARATI("gu", "গুজরাতি (Gujarati)", "Gujarati", "guj_Gujr"),
    PUNJABI("pa", "পাঞ্জাবি (Punjabi)", "Punjabi", "pan_Guru"),
    PERSIAN("fa", "ফার্সি (Persian)", "Persian", "pes_Arab"),
    DUTCH("nl", "ডাচ (Dutch)", "Dutch", "nld_Latn"),
    POLISH("pl", "পোলিশ (Polish)", "Polish", "pol_Latn"),
    SWEDISH("sv", "সুইডিশ (Swedish)", "Swedish", "swe_Latn"),
    THAI("th", "থাই (Thai)", "Thai", "tha_Thai");

    companion object {
        fun fromCode(code: String): SupportedLanguage {
            val clean = code.lowercase().trim()
            return entries.firstOrNull { it.code == clean || it.floresCode.equals(clean, ignoreCase = true) } ?: ENGLISH
        }

        val nonAutoLanguages: List<SupportedLanguage> get() = entries.filter { it != AUTO }
    }
}

enum class SubtitleLanguageOption(val label: String, val labelBangla: String) {
    ORIGINAL_LANGUAGE("Original Language", "মূল ভাষা"),
    TARGET_LANGUAGE("Target Language", "অনূদিত ভাষা"),
    BOTH("Bilingual (Original + Target)", "দ্বিভাষিক (মূল + অনুবাদ)")
}

enum class ExportFormat {
    MP4_VIDEO,
    AUDIO_ONLY,
    SRT_SUBTITLE,
    VTT_SUBTITLE,
    TRANSCRIPT_TXT
}

enum class VideoQuality(val label: String) {
    QUALITY_720P("720p HD"),
    QUALITY_1080P("1080p Full HD"),
    ORIGINAL("Original Quality")
}

enum class ExportAudioOption(val label: String) {
    ORIGINAL_AUDIO("Original Audio"),
    TRANSLATED_AUDIO("Translated Audio"),
    BOTH_AUDIO("Both (Dual Track)")
}
