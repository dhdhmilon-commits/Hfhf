package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.LocalAiService
import com.example.export.SubtitleExportHelper
import com.example.model.DialogueSegment
import com.example.model.ExportAudioOption
import com.example.model.ExportFormat
import com.example.model.JobQueueStatus
import com.example.model.LocalServerHardwareInfo
import com.example.model.ProcessingStep
import com.example.model.ProgressStepState
import com.example.model.Speaker
import com.example.model.SpeakerGender
import com.example.model.StepStatus
import com.example.model.SubtitleLanguageOption
import com.example.model.SupportedLanguage
import com.example.model.VideoItem
import com.example.model.VideoQuality
import com.example.model.VoiceProfile
import com.example.model.DubbingVoiceMode
import com.example.model.VoiceType
import com.example.tts.VoiceManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class VideoTranslatorViewModel(application: Application) : AndroidViewModel(application) {

    private val aiService = LocalAiService()
    val voiceManager = VoiceManager(application)

    // --- Local Server & Hardware Status (100% Offline, Zero Cloud API, Zero API Keys) ---
    private val _localServerInfo = MutableStateFlow(LocalServerHardwareInfo())
    val localServerInfo: StateFlow<LocalServerHardwareInfo> = _localServerInfo.asStateFlow()

    private val _jobQueueStatus = MutableStateFlow(JobQueueStatus.COMPLETED)
    val jobQueueStatus: StateFlow<JobQueueStatus> = _jobQueueStatus.asStateFlow()

    private val _showServerHubDialog = MutableStateFlow(false)
    val showServerHubDialog: StateFlow<Boolean> = _showServerHubDialog.asStateFlow()

    // --- Video Selection ---
    private val _videoItem = MutableStateFlow<VideoItem?>(null)
    val videoItem: StateFlow<VideoItem?> = _videoItem.asStateFlow()

    // --- Language Selection ---
    private val _sourceLanguage = MutableStateFlow(SupportedLanguage.BANGLA)
    val sourceLanguage: StateFlow<SupportedLanguage> = _sourceLanguage.asStateFlow()

    private val _targetLanguage = MutableStateFlow(SupportedLanguage.ENGLISH)
    val targetLanguage: StateFlow<SupportedLanguage> = _targetLanguage.asStateFlow()

    // --- Pipeline Progress States ---
    private val _pipelineSteps = MutableStateFlow(createInitialPipelineSteps())
    val pipelineSteps: StateFlow<List<ProgressStepState>> = _pipelineSteps.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // --- Analysis & Diarization Data ---
    private val _speakers = MutableStateFlow<List<Speaker>>(emptyList())
    val speakers: StateFlow<List<Speaker>> = _speakers.asStateFlow()

    private val _dialogues = MutableStateFlow<List<DialogueSegment>>(emptyList())
    val dialogues: StateFlow<List<DialogueSegment>> = _dialogues.asStateFlow()

    // --- Subtitle Options ---
    private val _showOriginalSubtitle = MutableStateFlow(true)
    val showOriginalSubtitle: StateFlow<Boolean> = _showOriginalSubtitle.asStateFlow()

    private val _showTranslatedSubtitle = MutableStateFlow(true)
    val showTranslatedSubtitle: StateFlow<Boolean> = _showTranslatedSubtitle.asStateFlow()

    private val _showSpeakerName = MutableStateFlow(true)
    val showSpeakerName: StateFlow<Boolean> = _showSpeakerName.asStateFlow()

    private val _showTimestamp = MutableStateFlow(true)
    val showTimestamp: StateFlow<Boolean> = _showTimestamp.asStateFlow()

    private val _subtitleLanguageOption = MutableStateFlow(SubtitleLanguageOption.BOTH)
    val subtitleLanguageOption: StateFlow<SubtitleLanguageOption> = _subtitleLanguageOption.asStateFlow()

    // --- Voice Cloning & Consent ---
    private val _voicePreservationConsentGranted = MutableStateFlow(false)
    val voicePreservationConsentGranted: StateFlow<Boolean> = _voicePreservationConsentGranted.asStateFlow()

    private val _showConsentDialog = MutableStateFlow(false)
    val showConsentDialog: StateFlow<Boolean> = _showConsentDialog.asStateFlow()

    // --- Video Preview Tabs (0 = Original, 1 = Translated) ---
    private val _previewTab = MutableStateFlow(0)
    val previewTab: StateFlow<Int> = _previewTab.asStateFlow()

    // --- Export Options ---
    private val _selectedExportFormat = MutableStateFlow(ExportFormat.MP4_VIDEO)
    val selectedExportFormat: StateFlow<ExportFormat> = _selectedExportFormat.asStateFlow()

    private val _selectedQuality = MutableStateFlow(VideoQuality.QUALITY_1080P)
    val selectedQuality: StateFlow<VideoQuality> = _selectedQuality.asStateFlow()

    private val _selectedAudioOption = MutableStateFlow(ExportAudioOption.TRANSLATED_AUDIO)
    val selectedAudioOption: StateFlow<ExportAudioOption> = _selectedAudioOption.asStateFlow()

    private val _exportSuccessMessage = MutableStateFlow<String?>(null)
    val exportSuccessMessage: StateFlow<String?> = _exportSuccessMessage.asStateFlow()

    private val _activeJobId = MutableStateFlow<String?>(null)
    val activeJobId: StateFlow<String?> = _activeJobId.asStateFlow()

    // --- Custom Voice Cloning & Library (XTTS-v2) ---
    private val _voiceProfiles = MutableStateFlow<List<VoiceProfile>>(emptyList())
    val voiceProfiles: StateFlow<List<VoiceProfile>> = _voiceProfiles.asStateFlow()

    private val _selectedVoiceMode = MutableStateFlow(DubbingVoiceMode.DEFAULT)
    val selectedVoiceMode: StateFlow<DubbingVoiceMode> = _selectedVoiceMode.asStateFlow()

    private val _selectedCustomVoiceId = MutableStateFlow<String?>(null)
    val selectedCustomVoiceId: StateFlow<String?> = _selectedCustomVoiceId.asStateFlow()

    private val _showVoiceLibraryDialog = MutableStateFlow(false)
    val showVoiceLibraryDialog: StateFlow<Boolean> = _showVoiceLibraryDialog.asStateFlow()

    private val _isUploadingVoice = MutableStateFlow(false)
    val isUploadingVoice: StateFlow<Boolean> = _isUploadingVoice.asStateFlow()

    private val _voiceUploadError = MutableStateFlow<String?>(null)
    val voiceUploadError: StateFlow<String?> = _voiceUploadError.asStateFlow()

    init {
        refreshServerStatus()
        loadVoiceProfiles()
    }

    fun loadVoiceProfiles() {
        viewModelScope.launch {
            try {
                val list = aiService.getVoiceProfiles(_localServerInfo.value.serverUrl)
                _voiceProfiles.value = list
                if (_selectedCustomVoiceId.value != null && list.none { it.id == _selectedCustomVoiceId.value }) {
                    _selectedCustomVoiceId.value = null
                    _selectedVoiceMode.value = DubbingVoiceMode.DEFAULT
                }
            } catch (_: Exception) {}
        }
    }

    fun setDubbingVoiceMode(mode: DubbingVoiceMode) {
        _selectedVoiceMode.value = mode
        if (mode == DubbingVoiceMode.DEFAULT) {
            _selectedCustomVoiceId.value = null
        } else if (_selectedCustomVoiceId.value == null && _voiceProfiles.value.isNotEmpty()) {
            _selectedCustomVoiceId.value = _voiceProfiles.value.first().id
        }
    }

    fun selectCustomVoice(voiceId: String?) {
        _selectedCustomVoiceId.value = voiceId
        _selectedVoiceMode.value = if (voiceId != null) DubbingVoiceMode.CLONED else DubbingVoiceMode.DEFAULT
    }

    fun openVoiceLibraryDialog() {
        _showVoiceLibraryDialog.value = true
        _voiceUploadError.value = null
        loadVoiceProfiles()
    }

    fun closeVoiceLibraryDialog() {
        _showVoiceLibraryDialog.value = false
        _voiceUploadError.value = null
    }

    fun uploadCustomVoice(name: String, audioUri: Uri, fileName: String) {
        _isUploadingVoice.value = true
        _voiceUploadError.value = null
        viewModelScope.launch {
            try {
                val cr = getApplication<Application>().contentResolver
                val newProfile = aiService.uploadVoiceProfile(
                    serverUrl = _localServerInfo.value.serverUrl,
                    name = name.ifBlank { "আমার ভয়েস" },
                    audioUri = audioUri,
                    contentResolver = cr,
                    fileName = fileName
                )
                loadVoiceProfiles()
                _selectedCustomVoiceId.value = newProfile.id
                _selectedVoiceMode.value = DubbingVoiceMode.CLONED
                _isUploadingVoice.value = false
            } catch (e: Exception) {
                _isUploadingVoice.value = false
                _voiceUploadError.value = "ভয়েস আপলোড ব্যর্থ: ${e.message}"
            }
        }
    }

    fun deleteCustomVoice(voiceId: String) {
        viewModelScope.launch {
            try {
                aiService.deleteVoiceProfile(_localServerInfo.value.serverUrl, voiceId)
                loadVoiceProfiles()
            } catch (_: Exception) {}
        }
    }

    fun openServerHubDialog() {
        _showServerHubDialog.value = true
    }

    fun closeServerHubDialog() {
        _showServerHubDialog.value = false
    }

    fun updateLocalServerUrl(newUrl: String) {
        _localServerInfo.value = _localServerInfo.value.copy(serverUrl = newUrl)
        refreshServerStatus()
    }

    fun refreshServerStatus() {
        viewModelScope.launch {
            val url = _localServerInfo.value.serverUrl
            val info = aiService.checkLocalServerHealth(url)
            _localServerInfo.value = info
        }
    }

    private fun createInitialPipelineSteps(): List<ProgressStepState> {
        return ProcessingStep.entries.map {
            ProgressStepState(step = it, status = StepStatus.PENDING, progressPercent = 0)
        }
    }

    fun loadSampleVideo(sampleId: String = "sample_bangla_dialogue.mp4") {
        val isEnglish = sampleId.contains("english", ignoreCase = true)
        val video = VideoItem(
            uri = null,
            fileName = if (isEnglish) "English_Conversation_Demo.mp4" else "Bangla_Market_Conversation.mp4",
            fileSizeFormatted = "14.2 MB",
            durationMs = 21000L,
            durationFormatted = "00:21",
            format = "MP4 (H.264 / AAC)",
            isSample = true
        )
        _videoItem.value = video
        if (isEnglish) {
            _sourceLanguage.value = SupportedLanguage.ENGLISH
            _targetLanguage.value = SupportedLanguage.BANGLA
        } else {
            _sourceLanguage.value = SupportedLanguage.BANGLA
            _targetLanguage.value = SupportedLanguage.ENGLISH
        }
        resetPipeline()
    }

    fun selectVideoUri(context: Context, uri: Uri) {
        try {
            var fileName = "Selected_Video.mp4"
            var fileSize = 12 * 1024 * 1024L

            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: fileName
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }

            val extension = fileName.substringAfterLast('.', "mp4").uppercase()
            val sizeMb = String.format("%.1f MB", fileSize / (1024.0 * 1024.0))

            _videoItem.value = VideoItem(
                uri = uri,
                fileName = fileName,
                fileSizeFormatted = sizeMb,
                durationMs = 32000L,
                durationFormatted = "00:32",
                format = extension,
                isSample = false
            )
            resetPipeline()
        } catch (e: Exception) {
            _errorMessage.value = "Failed to load selected video: ${e.message}"
        }
    }

    fun removeVideo() {
        _videoItem.value = null
        resetPipeline()
    }

    fun setSourceLanguage(lang: SupportedLanguage) {
        _sourceLanguage.value = lang
    }

    fun setTargetLanguage(lang: SupportedLanguage) {
        _targetLanguage.value = lang
    }

    fun swapLanguages() {
        val currentSource = _sourceLanguage.value
        val currentTarget = _targetLanguage.value

        val newSource = if (currentSource == SupportedLanguage.AUTO) SupportedLanguage.ENGLISH else currentTarget
        val newTarget = if (currentSource == SupportedLanguage.AUTO) SupportedLanguage.BANGLA else currentSource

        _sourceLanguage.value = newSource
        _targetLanguage.value = newTarget
    }

    fun resetPipeline() {
        _pipelineSteps.value = createInitialPipelineSteps()
        _speakers.value = emptyList()
        _dialogues.value = emptyList()
        _errorMessage.value = null
        _isProcessing.value = false
        _previewTab.value = 0
    }

    fun analyzeVideo() {
        val currentVideo = _videoItem.value ?: return
        _isProcessing.value = true
        _errorMessage.value = null
        _jobQueueStatus.value = JobQueueStatus.QUEUED

        viewModelScope.launch {
            try {
                val serverUrl = _localServerInfo.value.serverUrl
                
                // 1. Health check - verify local backend is running
                val health = aiService.checkLocalServerHealth(serverUrl)
                _localServerInfo.value = health
                if (!health.isServerConnected) {
                    throw com.example.ai.LocalServerOfflineException(serverUrl)
                }

                _jobQueueStatus.value = JobQueueStatus.PROCESSING
                updateStep(ProcessingStep.UPLOADING, StepStatus.IN_PROGRESS, 5, "ভিডিও স্ট্রিম প্রস্তুত করা হচ্ছে...")

                // 2. Stream video directly from ContentResolver (No OutOfMemory on 20-min videos)
                val uri = currentVideo.uri ?: throw IllegalStateException("ভিডিও ফাইল পাওয়া যায়নি। অনুগ্রহ করে আপনার ডিভাইস থেকে একটি আসল ভিডিও সিলেক্ট করুন।")
                val contentResolver = getApplication<Application>().contentResolver
                val uploadFileName = currentVideo.fileName.ifBlank { "video.mp4" }

                // 3. Submit job to local server via streaming (Zero external API, Zero keys)
                val jobId = aiService.submitVideoJobStream(
                    serverUrl = serverUrl,
                    videoUri = uri,
                    contentResolver = contentResolver,
                    fileName = uploadFileName,
                    sourceLang = _sourceLanguage.value.code,
                    targetLang = _targetLanguage.value.code,
                    voiceMode = _selectedVoiceMode.value.id,
                    customVoiceId = if (_selectedVoiceMode.value == DubbingVoiceMode.CLONED) _selectedCustomVoiceId.value else null,
                    onProgress = { uploadPct ->
                        updateStep(
                            ProcessingStep.UPLOADING,
                            StepStatus.IN_PROGRESS,
                            uploadPct,
                            "ভিডিও লোকাল সার্ভারে আপলোড হচ্ছে: $uploadPct%..."
                        )
                    }
                )
                _activeJobId.value = jobId
                updateStep(ProcessingStep.UPLOADING, StepStatus.COMPLETED, 100, "ভিডিও সার্ভারে আপলোড সম্পন্ন!")

                // 4. Poll real progress from local worker with transient error tolerance
                var isCompleted = false
                var consecutiveErrors = 0
                val maxErrors = 12

                while (!isCompleted) {
                    delay(1500)
                    try {
                        val status = aiService.getJobStatus(serverUrl, jobId)
                        consecutiveErrors = 0
                        syncPipelineWithBackendStep(status.currentStep, status.progressPercent, status.statusMessage)

                        when (status.status) {
                            "COMPLETED" -> {
                                isCompleted = true
                            }
                            "FAILED" -> {
                                val msg = status.errorMessage ?: status.statusMessage
                                throw RuntimeException(msg)
                            }
                            else -> {
                                // In progress
                            }
                        }
                    } catch (e: Exception) {
                        if (e is RuntimeException && e.message?.contains("ভিডিও") == true) {
                            throw e
                        }
                        consecutiveErrors++
                        if (consecutiveErrors >= maxErrors) {
                            throw e
                        }
                        // Retry gracefully during transient network lag on long 20-minute jobs
                    }
                }

                // 5. Fetch actual analyzed speakers and dialogues from local server
                val (spks, segs) = aiService.getJobResult(serverUrl, jobId)
                _speakers.value = spks
                _dialogues.value = segs

                // Mark all pipeline steps completed
                _pipelineSteps.value = _pipelineSteps.value.map {
                    it.copy(status = StepStatus.COMPLETED, progressPercent = 100)
                }
                _jobQueueStatus.value = JobQueueStatus.COMPLETED
                _isProcessing.value = false
            } catch (e: Exception) {
                _isProcessing.value = false
                _jobQueueStatus.value = JobQueueStatus.FAILED
                markCurrentStepFailed()
                _errorMessage.value = e.message ?: "Something went wrong. Please try again."
            }
        }
    }

    private fun syncPipelineWithBackendStep(backendStep: String, progress: Int, message: String = "") {
        when (backendStep) {
            "LOCAL_AUDIO_EXTRACTION" -> {
                updateStep(ProcessingStep.EXTRACTING_AUDIO, StepStatus.IN_PROGRESS, progress, message)
            }
            "LOCAL_SPEECH_TO_TEXT" -> {
                updateStep(ProcessingStep.EXTRACTING_AUDIO, StepStatus.COMPLETED, 100)
                updateStep(ProcessingStep.TRANSCRIBING, StepStatus.IN_PROGRESS, progress, message)
            }
            "LOCAL_SPEAKER_DIARIZATION" -> {
                updateStep(ProcessingStep.TRANSCRIBING, StepStatus.COMPLETED, 100)
                updateStep(ProcessingStep.DETECTING_SPEAKERS, StepStatus.IN_PROGRESS, progress, message)
            }
            "LOCAL_TRANSLATION" -> {
                updateStep(ProcessingStep.DETECTING_SPEAKERS, StepStatus.COMPLETED, 100)
                updateStep(ProcessingStep.TRANSLATING, StepStatus.IN_PROGRESS, progress, message)
            }
            "LOCAL_TEXT_TO_SPEECH" -> {
                updateStep(ProcessingStep.TRANSLATING, StepStatus.COMPLETED, 100)
                updateStep(ProcessingStep.GENERATING_VOICE, StepStatus.IN_PROGRESS, progress, message)
            }
            "LOCAL_VIDEO_RENDERING" -> {
                updateStep(ProcessingStep.GENERATING_VOICE, StepStatus.COMPLETED, 100)
                updateStep(ProcessingStep.RENDERING_VIDEO, StepStatus.IN_PROGRESS, progress, message)
            }
        }
    }

    private fun getVideoBytes(videoItem: VideoItem): Pair<ByteArray, String> {
        val uri = videoItem.uri ?: throw IllegalStateException("ভিডিও ফাইল পাওয়া যায়নি। অনুগ্রহ করে আপনার ডিভাইস থেকে একটি আসল ভিডিও সিলেক্ট করুন।")
        val stream = getApplication<Application>().contentResolver.openInputStream(uri)
            ?: throw java.io.IOException("ভিডিও ফাইলটি রিড করা যায়নি")
        val bytes = stream.use { it.readBytes() }
        return Pair(bytes, videoItem.fileName)
    }

    fun translateVideo() {
        val segs = _dialogues.value
        if (segs.isEmpty()) {
            analyzeVideo()
            return
        }

        _isProcessing.value = true
        _errorMessage.value = null
        _jobQueueStatus.value = JobQueueStatus.PROCESSING

        viewModelScope.launch {
            try {
                // Re-run full pipeline with updated target language
                analyzeVideo()
                _previewTab.value = 1
            } catch (e: Exception) {
                _isProcessing.value = false
                _errorMessage.value = e.message ?: "Something went wrong. Please try again."
                _jobQueueStatus.value = JobQueueStatus.FAILED
                updateStep(ProcessingStep.TRANSLATING, StepStatus.FAILED, 65)
            }
        }
    }

    fun generateTranslatedVoice() {
        val segs = _dialogues.value
        if (segs.isEmpty()) return

        _isProcessing.value = true
        _errorMessage.value = null
        _jobQueueStatus.value = JobQueueStatus.PROCESSING

        viewModelScope.launch {
            try {
                updateStep(ProcessingStep.GENERATING_VOICE, StepStatus.IN_PROGRESS, 35)
                delay(600)
                updateStep(ProcessingStep.GENERATING_VOICE, StepStatus.IN_PROGRESS, 80)
                delay(500)
                updateStep(ProcessingStep.GENERATING_VOICE, StepStatus.COMPLETED, 100)

                // Pre-warm preview of the first speaker voice
                val firstSpk = _speakers.value.firstOrNull()
                val firstSeg = segs.firstOrNull()
                if (firstSpk != null && firstSeg != null) {
                    val sample = firstSeg.translatedText.ifBlank { firstSeg.originalText }
                    voiceManager.speakPreview(firstSpk, sample, _targetLanguage.value.code)
                }

                _isProcessing.value = false
                _jobQueueStatus.value = JobQueueStatus.COMPLETED
                _previewTab.value = 1
            } catch (e: Exception) {
                _isProcessing.value = false
                _errorMessage.value = "Something went wrong. Please try again."
                _jobQueueStatus.value = JobQueueStatus.FAILED
                updateStep(ProcessingStep.GENERATING_VOICE, StepStatus.FAILED, 50)
            }
        }
    }

    fun renderAndExportVideo(context: Context) {
        _isProcessing.value = true
        _errorMessage.value = null
        _jobQueueStatus.value = JobQueueStatus.PROCESSING

        viewModelScope.launch {
            try {
                val jobId = _activeJobId.value
                val serverUrl = _localServerInfo.value.serverUrl
                val format = _selectedExportFormat.value

                when (format) {
                    ExportFormat.MP4_VIDEO -> {
                        if (jobId == null) {
                            throw IllegalStateException("কোনো সম্পন্ন অনুবাদ জব পাওয়া যায়নি। প্রথমে ভিডিও ট্রান্সলেট করুন।")
                        }
                        updateStep(ProcessingStep.RENDERING_VIDEO, StepStatus.IN_PROGRESS, 30)
                        val videoBytes = aiService.downloadExportFile(serverUrl, jobId, "mp4")
                        updateStep(ProcessingStep.RENDERING_VIDEO, StepStatus.COMPLETED, 100)
                        val fileName = "fluentvideo_${_targetLanguage.value.code}_output.mp4"
                        SubtitleExportHelper.shareExportBinaryFile(context, videoBytes, fileName, "video/mp4")
                        _exportSuccessMessage.value = "অনূদিত ভিডিও ($fileName) সফলভাবে ডাউনলোড হয়েছে!"
                    }
                    ExportFormat.AUDIO_ONLY -> {
                        if (jobId == null) {
                            throw IllegalStateException("কোনো সম্পন্ন অনুবাদ জব পাওয়া যায়নি। প্রথমে ভিডিও ট্রান্সলেট করুন।")
                        }
                        updateStep(ProcessingStep.RENDERING_VIDEO, StepStatus.IN_PROGRESS, 30)
                        val audioBytes = aiService.downloadExportFile(serverUrl, jobId, "audio")
                        updateStep(ProcessingStep.RENDERING_VIDEO, StepStatus.COMPLETED, 100)
                        val fileName = "fluentvideo_dubbed_${_targetLanguage.value.code}.wav"
                        SubtitleExportHelper.shareExportBinaryFile(context, audioBytes, fileName, "audio/wav")
                        _exportSuccessMessage.value = "ডাবড অডিও ($fileName) সফলভাবে ডাউনলোড হয়েছে!"
                    }
                    ExportFormat.SRT_SUBTITLE -> {
                        val srtContent = if (jobId != null) {
                            try {
                                val srtBytes = aiService.downloadExportFile(serverUrl, jobId, "srt")
                                String(srtBytes, Charsets.UTF_8)
                            } catch (_: Exception) {
                                SubtitleExportHelper.generateSrt(
                                    _dialogues.value,
                                    _speakers.value,
                                    _subtitleLanguageOption.value,
                                    _showSpeakerName.value
                                )
                            }
                        } else {
                            SubtitleExportHelper.generateSrt(
                                _dialogues.value,
                                _speakers.value,
                                _subtitleLanguageOption.value,
                                _showSpeakerName.value
                            )
                        }
                        val fileName = "subtitles_${_targetLanguage.value.code}.srt"
                        SubtitleExportHelper.shareExportFile(context, srtContent, fileName, "application/x-subrip")
                        _exportSuccessMessage.value = "সাবটাইটেল ($fileName) সফলভাবে এক্সপোর্ট করা হয়েছে!"
                    }
                    ExportFormat.VTT_SUBTITLE -> {
                        val vtt = SubtitleExportHelper.generateVtt(
                            _dialogues.value,
                            _speakers.value,
                            _subtitleLanguageOption.value,
                            _showSpeakerName.value
                        )
                        val fileName = "subtitles_${_targetLanguage.value.code}.vtt"
                        SubtitleExportHelper.shareExportFile(context, vtt, fileName, "text/vtt")
                        _exportSuccessMessage.value = "VTT সাবটাইটেল ($fileName) এক্সপোর্ট করা হয়েছে!"
                    }
                    ExportFormat.TRANSCRIPT_TXT -> {
                        val txt = SubtitleExportHelper.generateTranscriptTxt(
                            _dialogues.value,
                            _speakers.value
                        )
                        val fileName = "transcript_${_targetLanguage.value.code}.txt"
                        SubtitleExportHelper.shareExportFile(context, txt, fileName, "text/plain")
                        _exportSuccessMessage.value = "ট্রান্সক্রিপ্ট ($fileName) এক্সপোর্ট করা হয়েছে!"
                    }
                }
                _isProcessing.value = false
                _jobQueueStatus.value = JobQueueStatus.COMPLETED
            } catch (e: Exception) {
                _isProcessing.value = false
                _errorMessage.value = e.message ?: "ফাইল এক্সপোর্ট বা ডাউনলোড করতে ব্যর্থ হয়েছে।"
                updateStep(ProcessingStep.RENDERING_VIDEO, StepStatus.FAILED, 50)
            }
        }
    }

    private fun updateStep(step: ProcessingStep, status: StepStatus, progress: Int, subText: String = "") {
        _pipelineSteps.value = _pipelineSteps.value.map {
            if (it.step == step) {
                it.copy(status = status, progressPercent = progress, subStatusText = subText)
            } else it
        }
    }

    private fun markCurrentStepFailed() {
        _pipelineSteps.value = _pipelineSteps.value.map {
            if (it.status == StepStatus.IN_PROGRESS) {
                it.copy(status = StepStatus.FAILED)
            } else it
        }
    }

    // --- Speaker Editing ---
    fun updateSpeakerName(speakerId: String, newName: String) {
        _speakers.value = _speakers.value.map {
            if (it.id == speakerId) it.copy(customName = newName) else it
        }
    }

    fun updateSpeakerGender(speakerId: String, newGender: SpeakerGender) {
        _speakers.value = _speakers.value.map {
            if (it.id == speakerId) {
                val voice = when (newGender) {
                    SpeakerGender.FEMALE -> VoiceType.FEMALE_VOICE
                    SpeakerGender.MALE -> VoiceType.MALE_VOICE
                    SpeakerGender.UNKNOWN_NOT_CONFIDENT -> VoiceType.NEUTRAL_VOICE
                }
                it.copy(gender = newGender, selectedVoice = voice)
            } else it
        }
    }

    fun updateSpeakerVoiceType(speakerId: String, newVoice: VoiceType) {
        _speakers.value = _speakers.value.map {
            if (it.id == speakerId) it.copy(selectedVoice = newVoice) else it
        }
    }

    fun updateSpeakerPitch(speakerId: String, pitch: Float) {
        _speakers.value = _speakers.value.map {
            if (it.id == speakerId) it.copy(pitch = pitch) else it
        }
    }

    fun updateSpeakerSpeed(speakerId: String, speed: Float) {
        _speakers.value = _speakers.value.map {
            if (it.id == speakerId) it.copy(speed = speed) else it
        }
    }

    fun playSpeakerVoicePreview(speaker: Speaker) {
        val sampleDialogue = _dialogues.value.firstOrNull { it.speakerId == speaker.id }
        val sampleText = sampleDialogue?.translatedText?.ifBlank { sampleDialogue.originalText }
            ?: if (_targetLanguage.value == SupportedLanguage.BANGLA) "নমস্কার, আমি আপনার কথা শুনছি।" else "Hello, this is my voice preview."
        voiceManager.speakPreview(speaker, sampleText, _targetLanguage.value.code)
    }

    // --- Dialogue Editing ---
    fun updateDialogueText(dialogueId: String, original: String, translated: String) {
        _dialogues.value = _dialogues.value.map {
            if (it.id == dialogueId) it.copy(originalText = original, translatedText = translated) else it
        }
    }

    // --- Subtitle Options ---
    fun toggleShowOriginalSubtitle(enabled: Boolean) { _showOriginalSubtitle.value = enabled }
    fun toggleShowTranslatedSubtitle(enabled: Boolean) { _showTranslatedSubtitle.value = enabled }
    fun toggleShowSpeakerName(enabled: Boolean) { _showSpeakerName.value = enabled }
    fun toggleShowTimestamp(enabled: Boolean) { _showTimestamp.value = enabled }
    fun setSubtitleLanguageOption(option: SubtitleLanguageOption) { _subtitleLanguageOption.value = option }

    // --- Consent & Preview Tabs ---
    fun setVoiceCloningConsent(granted: Boolean) { _voicePreservationConsentGranted.value = granted }
    fun setShowConsentDialog(show: Boolean) { _showConsentDialog.value = show }
    fun setPreviewTab(tab: Int) { _previewTab.value = tab }

    // --- Export Options ---
    fun setExportFormat(format: ExportFormat) { _selectedExportFormat.value = format }
    fun setVideoQuality(quality: VideoQuality) { _selectedQuality.value = quality }
    fun setExportAudioOption(option: ExportAudioOption) { _selectedAudioOption.value = option }
    fun dismissExportSuccess() { _exportSuccessMessage.value = null }
    fun dismissError() { _errorMessage.value = null }

    override fun onCleared() {
        super.onCleared()
        voiceManager.shutdown()
    }
}
